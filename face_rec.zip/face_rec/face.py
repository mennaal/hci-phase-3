# import cv2
# from deepface import DeepFace

# # Load Haar Cascade for face detection
# face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

# # Start video capture from webcam
# cap = cv2.VideoCapture(0)

# while True:
#     ret, frame = cap.read()
#     gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

#     # Detect faces in the frame
#     faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)

#     for (x, y, w, h) in faces:
#         roi_color = frame[y:y+h, x:x+w]
        
#         # Analyze the ROI for emotions
#         analysis = DeepFace.analyze(roi_color, actions=['emotion'], enforce_detection=False)
        
#         dominant_emotion = analysis[0]['dominant_emotion']
        
#         cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
#         cv2.putText(frame, dominant_emotion, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 0, 0), 2)

#     cv2.imshow('Emotion Detection', frame)

#     if cv2.waitKey(1) & 0xFF == ord('q'):
#         break

# cap.release()
# cv2.destroyAllWindows()



#unknoun-emotion

import cv2
from deepface import DeepFace
import os

# Load Haar Cascade for face detection
face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

# Path to your face database
face_db_path = 'database/'

# Start video capture from webcam
cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Detect faces in the frame
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)

    for (x, y, w, h) in faces:
        roi_color = frame[y:y+h, x:x+w]

        try:
            # Identify the person
            result = DeepFace.find(
                img_path=roi_color,
                db_path=face_db_path,
                enforce_detection=False
            )

            # Extract the name of the identified person
            if len(result) > 0:
                person_name = os.path.basename(result[0].identity.values[0]).split('.')[0]  # Extract name
            else:
                person_name = "Unknown"

        except Exception as e:
            person_name = "Unknown"

        try:
            # Analyze the ROI for emotions
            analysis = DeepFace.analyze(roi_color, actions=['emotion'], enforce_detection=False)
            dominant_emotion = analysis[0]['dominant_emotion']

        except Exception as e:
            dominant_emotion = "No Emotion"

        # Draw rectangle around the face
        cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)

        # Display the name and emotion on the face
        text = f"{person_name} - {dominant_emotion}"
        cv2.putText(frame, text, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 0, 0), 2)

    # Show the video feed
    cv2.imshow('Person and Emotion Detection', frame)

    # Break loop on pressing 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()




