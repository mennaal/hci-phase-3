﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using TUIO;

namespace ZooEncyclopedia
{
    public partial class Form1 : Form, TuioListener
    {
        private List<Animal> animals;
        private List<Animal> activeAnimals = new List<Animal>();
        private Animal draggedAnimal;
        private TuioClient tuioClient;
        private string feedbackMessage;
        private Brush feedbackBrush;
        private Timer feedbackTimer;
        private Timer dayNightTimer;
        private int messageDuration = 2000;
        private bool allAnimalsCorrect = false;
        private bool isGameStarted = false;
        private int selectedAnimalIndex = -1;
        private string finalMessage;
        private float angle = 0;
        private const int menuRadius = 200;
        private bool isBoy = false;  
        private bool isGenderSelected = false;  
        private float rotationAngle = 0f;  
        private float previousRotationAngle = 0f; 
        private float angleIncrement = 10f; 



        public Form1()
        {
            InitializeComponent();
            DoubleBuffered = true;
            InitializeFeedback();
            InitializeDayNightCycle();
            StartTUIOClient();
            this.Text = "Zoo Encyclopedia Game";
            this.Size = new Size(800, 600);
            SetDefaultBackground(); 
            InitializeAnimals(); 
            
        }

        
        private void InitializeFeedback()
        {
            feedbackMessage = "Welcome to the Zoo Encyclopedia Game! Select an animal from the menu to start.";
            feedbackBrush = Brushes.Blue;
            feedbackTimer = new Timer();
            feedbackTimer.Interval = messageDuration;
            feedbackTimer.Tick += feedbackTimer_Tick;
            feedbackTimer.Start();
        }

        
        private void InitializeDayNightCycle()
        {
            dayNightTimer = new Timer();
            dayNightTimer.Interval = 10000; 
            dayNightTimer.Tick += (sender, e) =>
            {
                var currentHour = DateTime.Now.Hour;
                if (currentHour >= 6 && currentHour < 18)
                {
                    this.BackgroundImage = LoadImage("zoo3.jpg"); 
                }
                else
                {
                    this.BackgroundImage = LoadImage("night_zoo1.jpg"); 
                }
                this.BackgroundImageLayout = ImageLayout.Stretch;
            };
            dayNightTimer.Start();
        }

        private void InitializeAnimals()
        {
            animals = new List<Animal>
    {
        new Animal
        {
            MarkerId = 1,
            Name = "Elephant",
            Position = new Point(600, 50),
            HousePosition = new Point(600, 50), 
            AnimalImage = LoadImage("elephant.jpg"),
            HouseImage = LoadImage("elephant_shelter.jpg"),
            BackgroundImage = LoadImage("zoo3.jpg"),
        },
        new Animal
        {
            MarkerId = 2,
            Name = "Horse",
            Position = new Point(600, 250), 
            HousePosition = new Point(600, 250), 
            AnimalImage = LoadImage("hourse.jpg"),
            HouseImage = LoadImage("hourse_shel.jpg"),
            BackgroundImage = LoadImage("zoo3.jpg"),
        },
        new Animal
        {
            MarkerId = 3,
            Name = "Sheep",
            Position = new Point(600, 400), 
            HousePosition = new Point(600, 400),
            AnimalImage = LoadImage("sheep.jpg"),
            HouseImage = LoadImage("sheep shelter.jpg"),
            BackgroundImage = LoadImage("zoo3.jpg"),
        },
        new Animal
        {
            MarkerId = 4,
            Name = "Cat",
            Position = new Point(600, 50),
            HousePosition = new Point(600, 50), 
            AnimalImage = LoadImage("cat.jpg"),
            HouseImage = LoadImage("cat shelter.jpg"),
            BackgroundImage = LoadImage("night_zoo1.jpg"),
        },
        new Animal
        {
            MarkerId = 5,
            Name = "Dog",
            Position = new Point(600, 250), 
            HousePosition = new Point(600, 250), 
            AnimalImage = LoadImage("dog.jpg"),
            HouseImage = LoadImage("dog_house.jpg"),
            BackgroundImage = LoadImage("night_zoo1.jpg"),
        },
        new Animal
        {
            MarkerId = 6,
            Name = "Giraffe",
            Position = new Point(600, 400), 
            HousePosition = new Point(600, 400), 
            AnimalImage = LoadImage("giraffe.jpg"),
            HouseImage = LoadImage("giraffe_safari.jpg"),
            BackgroundImage = LoadImage("night_zoo1.jpg"),
        },
    };
        }



        
        private Image LoadImage(string path)
        {
            try
            {
                return Image.FromFile(path);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading image '{path}': {ex.Message}");
                return null;
            }
        }

        
        private void StartTUIOClient()
        {
            tuioClient = new TuioClient(3333);
            tuioClient.addTuioListener(this);
            tuioClient.connect();
        }


        
        


        public void addTuioObject(TuioObject to)
        {

            if (to.SymbolID == 8) // Boy selected
            {
                isBoy = true;
                feedbackMessage = "You selected: Boy!";
                feedbackBrush = Brushes.Blue;
                isGenderSelected = true;
                feedbackTimer.Start();
                Invalidate();
                return;
            }
            else if (to.SymbolID == 9) // Girl selected
            {
                isBoy = false;
                feedbackMessage = "You selected: Girl!";
                feedbackBrush = Brushes.Pink;
                isGenderSelected = true;
                feedbackTimer.Start();
                Invalidate();
                return;
            }




           if (!isGameStarted && to.SymbolID == 12) 
{
    
    var unplacedAnimals = isBoy
        ? animals.Where(a => (a.MarkerId == 1 || a.MarkerId == 2 || a.MarkerId == 3) && !a.IsInCorrectHouse).ToList()
        : animals.Where(a => (a.MarkerId == 4 || a.MarkerId == 5 || a.MarkerId == 6) && !a.IsInCorrectHouse).ToList();

    if (unplacedAnimals.Count > 0)
    {
        
        selectedAnimalIndex = (int)((angle / 360) * unplacedAnimals.Count) % unplacedAnimals.Count;
        var selectedAnimal = unplacedAnimals[selectedAnimalIndex];

        
        UpdateBackgroundImage(selectedAnimal);

        
        if (!activeAnimals.Contains(selectedAnimal))
        {
            activeAnimals.Add(selectedAnimal);
        }

        
        feedbackMessage = $"{selectedAnimal.Name} selected!";
        feedbackBrush = Brushes.Green;
        feedbackTimer.Start();
        isGameStarted = true;

        
        selectedAnimal.Position = new Point(50, this.ClientSize.Height / 2);

        
        Invalidate();
    }
}


            
            if (isGameStarted && selectedAnimalIndex != -1)
            {
                var selectedAnimal = activeAnimals.Last(); 

                if (selectedAnimal.MarkerId == to.SymbolID) 
                {
                    int scaledX = (int)(to.X * this.ClientSize.Width); 
                    int scaledY = (int)(to.Y * this.ClientSize.Height); 

                    selectedAnimal.Position = new Point(scaledX, scaledY); 
                    draggedAnimal = selectedAnimal; 

                    Invalidate(); 
                }
            }
        }

        private void HandleAnimalSelection(List<Animal> selectedAnimals, TuioObject to)
{
if (!isGameStarted)
{
 var unplacedAnimals = selectedAnimals.Where(a => !a.IsInCorrectHouse).ToList();
 if (unplacedAnimals.Count > 0)
 {
     selectedAnimalIndex = (int)((angle / 360) * unplacedAnimals.Count) % unplacedAnimals.Count;
     var selectedAnimal = unplacedAnimals[selectedAnimalIndex];
     this.BackgroundImage = selectedAnimal.BackgroundImage;
     this.BackgroundImageLayout = ImageLayout.Stretch;

     if (!activeAnimals.Contains(selectedAnimal))
     {
         activeAnimals.Add(selectedAnimal);
     }
     feedbackMessage = $"{selectedAnimal.Name} selected!";
     feedbackBrush = Brushes.Green;
     feedbackTimer.Start();
     isGameStarted = true;
     Invalidate();
 }
}
}


public void updateTuioObject(TuioObject to)
{
if (to.SymbolID == 11) 
{
 
 float deltaAngle = to.Angle - previousRotationAngle;

 
 rotationAngle += deltaAngle * angleIncrement; 

 
 if (rotationAngle >= 360f) rotationAngle -= 360f;
 if (rotationAngle < 0f) rotationAngle += 360f;

 
 previousRotationAngle = to.Angle;


 Invalidate();
}
            if (isGameStarted && selectedAnimalIndex != -1)
            {
                var selectedAnimal = animals[selectedAnimalIndex];
                if (selectedAnimal.MarkerId == to.SymbolID)
                {
                    int scaledX = (int)(to.X * this.ClientSize.Width);
                    int scaledY = (int)(to.Y * this.ClientSize.Height);
                    selectedAnimal.Position = new Point(scaledX, scaledY);
                    Invalidate();
                }
            }
        }




 
 public void removeTuioObject(TuioObject to)
 {
     if (isGameStarted && draggedAnimal != null && draggedAnimal.MarkerId == to.SymbolID)
     {
         CheckAnimalPlacement(draggedAnimal);
         draggedAnimal = null;
     }
 }

        private void CheckAnimalPlacement(Animal animal)
        {
            if (IsAnimalInHouse(animal))
            {
                animal.Position = animal.HousePosition;
                animal.IsInCorrectHouse = true;  
                SetFeedback($"{animal.Name} placed correctly!", Brushes.Green);

                selectedAnimalIndex = -1;
                isGameStarted = false;

                CheckCompletion();
                Invalidate();
            }
            else
            {
                animal.IsInCorrectHouse = false;
                SetFeedback("Wrong placement, try again!", Brushes.Red);
            }
        }


        private bool IsAnimalInHouse(Animal animal)
        {
            
            return (Math.Abs(animal.Position.X - animal.HousePosition.X) < 100 && Math.Abs(animal.Position.Y - animal.HousePosition.Y) < 100);
        }






        private void CheckCompletion()
 {
     if (animals.TrueForAll(a => a.IsInCorrectHouse) && !allAnimalsCorrect)
     {
         allAnimalsCorrect = true;
         finalMessage = "Great job, all is correct!";
         Invalidate();
     }
 }

 public void addTuioBlob(TuioBlob tb) { }
public void updateTuioBlob(TuioBlob tb) { }
public void removeTuioBlob(TuioBlob tb) { }
public void addTuioCursor(TuioCursor tc) { }
public void updateTuioCursor(TuioCursor tc) { }
public void removeTuioCursor(TuioCursor tc) { }
public void refresh(TuioTime time) { }


private void SetFeedback(string message, Brush color)
{
feedbackMessage = message;
feedbackBrush = color;
feedbackTimer.Start();
}

private void feedbackTimer_Tick(object sender, EventArgs e)
    {
        feedbackMessage = "";
        Invalidate();  
    }


private void SetDefaultBackground()
{
this.BackgroundImage = LoadImage("zoo3.jpg"); 
this.BackgroundImageLayout = ImageLayout.Stretch;
}

       
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            if (!isGameStarted)
            {
                
                DrawCircularMenu(e.Graphics);
                return;
            }

            DrawAnimals(e.Graphics);
            DrawHouses(e.Graphics);
            DrawFeedback(e.Graphics);

           
            DrawFeedback(e.Graphics);

           
            if (allAnimalsCorrect)
            {
                e.Graphics.DrawString(finalMessage, new Font("Arial", 24, FontStyle.Bold), Brushes.Blue, this.ClientSize.Width / 2 - 200, this.ClientSize.Height / 2 + 150);
            }

           
            if (isGameStarted && activeAnimals.Count > 0)
            {
                var selectedAnimal = activeAnimals.Last();
               
                DrawSelectedAnimalAndShelter(e.Graphics, selectedAnimal);
            }
        }
        private void DrawSelectedAnimalAndShelter(Graphics g, Animal selectedAnimal)
        {
           
            g.DrawImage(selectedAnimal.AnimalImage, selectedAnimal.Position.X - 50, selectedAnimal.Position.Y - 50, 100, 100);  // Adjust size and position as needed

            // Draw the shelter near the selected animal's position
           /* if (selectedAnimal.IsInCorrectHouse)
            {
                // If the animal is placed correctly, draw its shelter near its position
                g.DrawImage(selectedAnimal.HouseImage, selectedAnimal.Position.X - 50, selectedAnimal.Position.Y - 150, 100, 100);  // Adjust position for visual balance
            }
            else
            {
                // If the animal is not placed in the correct house yet, show the shelter next to the animal
                g.DrawImage(selectedAnimal.HouseImage, selectedAnimal.Position.X + 100, selectedAnimal.Position.Y - 50, 100, 100);  // Adjust as needed
            }*/
        }


        private void DrawShelterForSelectedAnimal(Graphics g, Animal selectedAnimal)
        {
           
            g.DrawImage(selectedAnimal.HouseImage, selectedAnimal.Position.X - 50, selectedAnimal.Position.Y - 50, 100, 100); // Adjust position and size as needed
        }

        private void DrawCircularMenu(Graphics g)
        {
            if (!isGenderSelected) return;  

            
            PointF center = new PointF(ClientSize.Width / 2, ClientSize.Height / 2);

          
            List<Animal> selectedAnimals = isBoy
                ? animals.Where(a => (a.MarkerId == 1 || a.MarkerId == 2 || a.MarkerId == 3) && !a.IsInCorrectHouse).ToList()  
                : animals.Where(a => (a.MarkerId == 4 || a.MarkerId == 5 || a.MarkerId == 6) && !a.IsInCorrectHouse).ToList(); 

            int animalCount = selectedAnimals.Count;
            if (animalCount == 0) return; 
            float angleIncrement = 360f / animalCount;

           
            float rotatedAngle = rotationAngle; 
            for (int i = 0; i < animalCount; i++)
            {
                Animal animal = selectedAnimals[i];

              
                float angle = rotatedAngle + angleIncrement * i;

                
                float x = center.X + menuRadius * (float)Math.Cos(Math.PI * angle / 180f) - 40;  
                float y = center.Y + menuRadius * (float)Math.Sin(Math.PI * angle / 180f) - 40;  

               
                g.DrawImage(animal.AnimalImage, x, y, 80, 80);

              
                if (isGameStarted && activeAnimals.Contains(animal))  
                {
                    g.DrawImage(animal.HouseImage, x - 50, y - 50, 100, 100); 
                }
            }
        }



        private void DrawAnimals(Graphics g)
        {
            foreach (var animal in activeAnimals)
            {
                g.DrawImage(animal.AnimalImage, animal.Position.X - 50, animal.Position.Y - 50, 100, 100);
            }
        }


      
        private void DrawHouses(Graphics g)
        {
           
            if (!isGenderSelected) return; 

            List<Animal> selectedAnimals = isBoy
                ? animals.Where(a => a.MarkerId == 1 || a.MarkerId == 2 || a.MarkerId == 3).ToList()  
                : animals.Where(a => a.MarkerId == 4 || a.MarkerId == 5 || a.MarkerId == 6).ToList(); 

            
            Debug.WriteLine("Selected animals for drawing shelters:");
            foreach (var animal in selectedAnimals)
            {
                Debug.WriteLine("Drawing shelter for animal: " + animal.Name); 
                g.DrawImage(animal.HouseImage, animal.HousePosition.X - 50, animal.HousePosition.Y - 50, 100, 100);
            }
        }
        



        private void DrawFeedback(Graphics g)
        {
            if (!string.IsNullOrEmpty(feedbackMessage))
            {
                g.DrawString(feedbackMessage, new Font("Arial", 16, FontStyle.Bold), feedbackBrush, new PointF(20, 20));
            }
        }



    private void UpdateBackgroundImage(Animal selectedAnimal)
        {
            this.BackgroundImage = selectedAnimal.BackgroundImage;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }
    }

public class Animal
{
 public int MarkerId { get; set; }
 public string Name { get; set; }
 public Point Position { get; set; }
 public Point HousePosition { get; set; }
 public Image AnimalImage { get; set; }
 public Image HouseImage { get; set; }
 public Image BackgroundImage { get; set; }
 public bool IsInCorrectHouse { get; set; } = false;

 public bool IsBoyAnimal { get; set; } 
 public bool IsGirlAnimal { get; set; } 
}

}





