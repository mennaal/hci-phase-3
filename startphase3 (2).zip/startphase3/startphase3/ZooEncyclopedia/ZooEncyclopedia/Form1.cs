﻿using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using TUIO;
using System.Net.Http;

namespace ZooEncyclopedia
{
    public partial class Form1 : Form, TuioListener
    {
        private List<Animal> animals;
        private List<Animal> activeAnimals = new List<Animal>();
        private Animal draggedAnimal;
        private TuioClient tuioClient;
        private string feedbackMessage;
        private Brush feedbackBrush;
        private System.Windows.Forms.Timer feedbackTimer;
        private System.Windows.Forms.Timer dayNightTimer;
        private int messageDuration = 2000;
        private bool allAnimalsCorrect = false;
        private bool isGameStarted = false;
        private int selectedAnimalIndex = -1;
        private string finalMessage;
        private float angle = 0;
        //private float angleIncrement = 5f;
        private const int menuRadius = 200;
        private bool isBoy = false;  // Default to false (Girl)
        private bool isGenderSelected = false;  // Flag to track if gender is selected
        private float rotationAngle = 0f;  // Store the rotation angle
        private float previousRotationAngle = 0f;  // To track the previous rotation angle for smooth transitions
        private float angleIncrement = 10f; // Increment value for rotation


        private const int Port = 12345;
        private const string IpAddress = "127.0.0.1"; // You can replace it with a different IP if needed
        private Thread socketThread;
        private TcpClient tcpClient;
        private NetworkStream networkStream;
        private byte[] receivedBytes;
        public Form1()
        {
            InitializeComponent();
            DoubleBuffered = true;
            InitializeFeedback();
            InitializeDayNightCycle();
            StartTUIOClient();
            this.Text = "Zoo Encyclopedia Game";
            this.Size = new Size(800, 600);
            SetDefaultBackground(); // Initialize default background
            InitializeAnimals(); // Initialize animals
            StartSocketListener();
            //ShowGenderSelectionMessage(); // Show message box to prompt gender selection
        }
        private void StartSocketListener()
        {
            socketThread = new Thread(ListenForAnimalData);
            socketThread.IsBackground = true;
            socketThread.Start();
        }

        private void ListenForAnimalData()
        {
            tcpClient = new TcpClient(IpAddress, Port);
            networkStream = tcpClient.GetStream();
            receivedBytes = new byte[1024];

            while (true)
            {
                int bytesRead = networkStream.Read(receivedBytes, 0, receivedBytes.Length);
                if (bytesRead > 0)
                {
                    string message = Encoding.UTF8.GetString(receivedBytes, 0, bytesRead);
                    UpdateActiveAnimals(message);
                }
            }
        }
        private void UpdateActiveAnimals(string detectedAnimals)
        {
            if (!string.IsNullOrEmpty(detectedAnimals))
            {
                // Split the message received from Python (animal names) and update UI
                string[] animals = detectedAnimals.Split(',');
                activeAnimals.Clear();
                foreach (string animal in animals)
                {
                    // Example: Add animals to the active list
                    Animal detectedAnimal = new Animal { Name = animal.Trim() };
                    activeAnimals.Add(detectedAnimal);
                }

                Invalidate();  // Trigger repaint to reflect new animal data
            }
        }
        // Initialize feedback settings
        private void InitializeFeedback()
        {
            feedbackMessage = "Welcome to the Zoo Encyclopedia Game! Select an animal from the menu to start.";
            feedbackBrush = Brushes.Blue;
            feedbackTimer = new System.Windows.Forms.Timer();
            feedbackTimer.Interval = messageDuration;
            feedbackTimer.Tick += feedbackTimer_Tick;
            feedbackTimer.Start();
        }

        // Initialize day/night cycle based on the time of day
        private void InitializeDayNightCycle()
        {
            dayNightTimer = new System.Windows.Forms.Timer();
            dayNightTimer.Interval = 10000; // 10 seconds for testing (adjust to real day/night duration)
            dayNightTimer.Tick += (sender, e) =>
            {
                var currentHour = DateTime.Now.Hour;
                if (currentHour >= 6 && currentHour < 18)
                {
                    this.BackgroundImage = LoadImage("zoo3.jpg"); // Daytime background
                }
                else
                {
                    this.BackgroundImage = LoadImage("night_zoo1.jpg"); // Nighttime background
                }
                this.BackgroundImageLayout = ImageLayout.Stretch;
            };
            dayNightTimer.Start();
        }

        private void InitializeAnimals()
        {
            animals = new List<Animal>
    {
        new Animal
        {
            MarkerId = 1,
            Name = "Elephant",
            Position = new Point(600, 50), // Position of the animal
            HousePosition = new Point(600, 50), // Position of the shelter
            AnimalImage = LoadImage("elephant.jpg"),
            HouseImage = LoadImage("elephant_shelter.jpg"),
            BackgroundImage = LoadImage("zoo3.jpg"),
        },
        new Animal
        {
            MarkerId = 2,
            Name = "Horse",
            Position = new Point(600, 250), // Position of the animal
            HousePosition = new Point(600, 250), // Position of the shelter
            AnimalImage = LoadImage("hourse.jpg"),
            HouseImage = LoadImage("hourse_shel.jpg"),
            BackgroundImage = LoadImage("zoo3.jpg"),
        },
        new Animal
        {
            MarkerId = 3,
            Name = "Sheep",
            Position = new Point(600, 400), // Position of the animal
            HousePosition = new Point(600, 400), // Position of the shelter
            AnimalImage = LoadImage("sheep.jpg"),
            HouseImage = LoadImage("sheep shelter.jpg"),
            BackgroundImage = LoadImage("zoo3.jpg"),
        },
        new Animal
        {
            MarkerId = 4,
            Name = "Cat",
            Position = new Point(600, 50), // Position of the animal
            HousePosition = new Point(600, 50), // Position of the shelter
            AnimalImage = LoadImage("cat.jpg"),
            HouseImage = LoadImage("cat shelter.jpg"),
            BackgroundImage = LoadImage("night_zoo1.jpg"),
        },
        new Animal
        {
            MarkerId = 5,
            Name = "Dog",
            Position = new Point(600, 250), // Position of the animal
            HousePosition = new Point(600, 250), // Position of the shelter
            AnimalImage = LoadImage("dog.jpg"),
            HouseImage = LoadImage("dog_house.jpg"),
            BackgroundImage = LoadImage("night_zoo1.jpg"),
        },
        new Animal
        {
            MarkerId = 6,
            Name = "Giraffe",
            Position = new Point(600, 400), // Position of the animal
            HousePosition = new Point(600, 400), // Position of the shelter
            AnimalImage = LoadImage("giraffe.jpg"),
            HouseImage = LoadImage("giraffe_safari.jpg"),
            BackgroundImage = LoadImage("night_zoo1.jpg"),
        },
    };
        }



        // Load image from file
        private Image LoadImage(string path)
        {
            try
            {
                return Image.FromFile(path);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading image '{path}': {ex.Message}");
                return null;
            }
        }

        // Start TUIO client to listen for TUIO objects
        private void StartTUIOClient()
        {
            tuioClient = new TuioClient(3333);
            tuioClient.addTuioListener(this);
            tuioClient.connect();
        }


        // Show a message box prompting the user to choose TUIO 8 for Boy and TUIO 9 for Girl
        // Show a more friendly message box prompting the user to choose TUIO 8 for Boy and TUIO 9 for Girl
        /*private void ShowGenderSelectionMessage()
        {
            string message = "Please choose an option:\n" +
                             " - Boy -> 8\n" +
                             " - Girl -> 9";

            DialogResult result = MessageBox.Show(message,
                                                  "Select Gender",
                                                  MessageBoxButtons.OKCancel);

            if (result == DialogResult.Cancel)
            {
                Application.Exit(); // Exit the application if user cancels
            }
        }*/


        public void addTuioObject(TuioObject to)
        {
            // Handle gender selection
            if (to.SymbolID == 8) // Boy selected
            {
                isBoy = true;
                feedbackMessage = "You selected: Boy!";
                feedbackBrush = Brushes.Blue;
                isGenderSelected = true;
                feedbackTimer.Start();
                Invalidate(); // Redraw to reflect gender selection
                Debug.WriteLine("Boy selected: " + isBoy); // Debugging output
                return;
            }
            else if (to.SymbolID == 9) // Girl selected
            {
                isBoy = false;
                feedbackMessage = "You selected: Girl!";
                feedbackBrush = Brushes.Pink;
                isGenderSelected = true;
                feedbackTimer.Start();
                Invalidate(); // Redraw to reflect gender selection
                Debug.WriteLine("Girl selected: " + isBoy); // Debugging output
                return;
            }


            // Handle animal selection when ID 12 is used (select animal from menu)
            if (!isGameStarted && to.SymbolID == 12) // Select animal from menu
            {
                var unplacedAnimals = animals.FindAll(a => !a.IsInCorrectHouse);

                if (unplacedAnimals.Count > 0)
                {
                    selectedAnimalIndex = (int)((angle / 360) * unplacedAnimals.Count) % unplacedAnimals.Count;
                    var selectedAnimal = unplacedAnimals[selectedAnimalIndex];

                    UpdateBackgroundImage(selectedAnimal); // Update background on selection

                    if (!activeAnimals.Contains(selectedAnimal))
                    {
                        activeAnimals.Add(selectedAnimal);
                    }

                    feedbackMessage = $"{selectedAnimal.Name} selected!";
                    feedbackBrush = Brushes.Green;
                    feedbackTimer.Start();
                    isGameStarted = true;

                    // Set initial position for the selected animal on the left side of the screen
                    selectedAnimal.Position = new Point(50, this.ClientSize.Height / 2); // 50px from the left, centered vertically

                    Invalidate();  // Forces the screen to refresh and draw the animal in the new position (its original one)
                }
            }

            // Handle dragging an animal once it has been selected
            if (isGameStarted && selectedAnimalIndex != -1)
            {
                var selectedAnimal = activeAnimals.Last(); // Get the last active animal (the one that was just selected)

                if (selectedAnimal.MarkerId == to.SymbolID) // Check if the TUIO object matches the selected animal
                {
                    int scaledX = (int)(to.X * this.ClientSize.Width); // Convert the TUIO X to screen coordinates
                    int scaledY = (int)(to.Y * this.ClientSize.Height); // Convert the TUIO Y to screen coordinates

                    selectedAnimal.Position = new Point(scaledX, scaledY); // Update animal position
                    draggedAnimal = selectedAnimal; // Set the dragged animal to the selected one

                    Invalidate(); // Redraw the screen
                }
            }
        }
        // Handle animal selection when a TUIO object is detected
        private void HandleAnimalSelection(List<Animal> selectedAnimals, TuioObject to)
{
if (!isGameStarted)
{
 var unplacedAnimals = selectedAnimals.Where(a => !a.IsInCorrectHouse).ToList();
 if (unplacedAnimals.Count > 0)
 {
     selectedAnimalIndex = (int)((angle / 360) * unplacedAnimals.Count) % unplacedAnimals.Count;
     var selectedAnimal = unplacedAnimals[selectedAnimalIndex];
     this.BackgroundImage = selectedAnimal.BackgroundImage;
     this.BackgroundImageLayout = ImageLayout.Stretch;

     if (!activeAnimals.Contains(selectedAnimal))
     {
         activeAnimals.Add(selectedAnimal);
     }
     feedbackMessage = $"{selectedAnimal.Name} selected!";
     feedbackBrush = Brushes.Green;
     feedbackTimer.Start();
     isGameStarted = true;
     Invalidate();
 }
}
}

// Update TUIO object (not used in this example, but required for TuioListener implementation)
public void updateTuioObject(TuioObject to)
{
if (to.SymbolID == 11) // ID 11 used for rotation tracking
{
 // Calculate the delta in rotation (i.e., the difference from the previous angle)
 float deltaAngle = to.Angle - previousRotationAngle;

 // Increment the rotation angle with a fixed amount each time
 rotationAngle += deltaAngle * angleIncrement; // Multiply by a factor to control speed

 // Normalize the angle to keep it within 0 - 360 degrees
 if (rotationAngle >= 360f) rotationAngle -= 360f;
 if (rotationAngle < 0f) rotationAngle += 360f;

 // Update the previous rotation angle to the current one for the next update
 previousRotationAngle = to.Angle;

 // Call Invalidate() to trigger the OnPaint method and redraw the screen
 Invalidate();
}
            if (isGameStarted && selectedAnimalIndex != -1)
            {
                var selectedAnimal = animals[selectedAnimalIndex];
                if (selectedAnimal.MarkerId == to.SymbolID)
                {
                    int scaledX = (int)(to.X * this.ClientSize.Width);
                    int scaledY = (int)(to.Y * this.ClientSize.Height);
                    selectedAnimal.Position = new Point(scaledX, scaledY);
                    Invalidate();
                }
            }
        }




 // Remove TUIO object (not used in this example, but required for TuioListener implementation)
 public void removeTuioObject(TuioObject to)
 {
     if (isGameStarted && draggedAnimal != null && draggedAnimal.MarkerId == to.SymbolID)
     {
         CheckAnimalPlacement(draggedAnimal);
         draggedAnimal = null;
     }
 }

        private void CheckAnimalPlacement(Animal animal)
        {
            if (IsAnimalInHouse(animal))
            {
                animal.Position = animal.HousePosition;
                animal.IsInCorrectHouse = true;  // Mark the animal as placed correctly
                SetFeedback($"{animal.Name} placed correctly!", Brushes.Green);

                selectedAnimalIndex = -1;
                isGameStarted = false;

                CheckCompletion();
                Invalidate();
            }
            else
            {
                animal.IsInCorrectHouse = false;
                SetFeedback("Wrong placement, try again!", Brushes.Red);
            }
        }


        private bool IsAnimalInHouse(Animal animal)
        {
            return (Math.Abs(animal.Position.X - animal.HousePosition.X) < 50 && Math.Abs(animal.Position.Y - animal.HousePosition.Y) < 50);
        }





        private void CheckCompletion()
 {
     if (animals.TrueForAll(a => a.IsInCorrectHouse) && !allAnimalsCorrect)
     {
         allAnimalsCorrect = true;
         finalMessage = "Great job, all is correct!";
         Invalidate();
     }
 }

 // Other required TUIO listener methods
 public void addTuioBlob(TuioBlob tb) { }
public void updateTuioBlob(TuioBlob tb) { }
public void removeTuioBlob(TuioBlob tb) { }
public void addTuioCursor(TuioCursor tc) { }
public void updateTuioCursor(TuioCursor tc) { }
public void removeTuioCursor(TuioCursor tc) { }
public void refresh(TuioTime time) { }

// Feedback methods
private void SetFeedback(string message, Brush color)
{
feedbackMessage = message;
feedbackBrush = color;
feedbackTimer.Start();
}

private void feedbackTimer_Tick(object sender, EventArgs e)
    {
        feedbackMessage = "";
        Invalidate();  // Redraw after resetting the feedback message
    }

// Set the default background image
private void SetDefaultBackground()
{
this.BackgroundImage = LoadImage("zoo3.jpg"); // Set default background image
this.BackgroundImageLayout = ImageLayout.Stretch;
}

        // Override the Paint method to draw the game screen
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            if (!isGameStarted)
            {
                // Draw the circular menu if the game is not started
                DrawCircularMenu(e.Graphics);
                return;
            }

            // Draw animals and houses (shelters) after the game starts
            DrawAnimals(e.Graphics);
            DrawHouses(e.Graphics);
            DrawFeedback(e.Graphics);

            // Optionally, display feedback messages
            DrawFeedback(e.Graphics);

            // If all animals are placed correctly, show the final message
            if (allAnimalsCorrect)
            {
                e.Graphics.DrawString(finalMessage, new Font("Arial", 24, FontStyle.Bold), Brushes.Blue, this.ClientSize.Width / 2 - 200, this.ClientSize.Height / 2 + 150);
            }

            // Draw the shelter of the selected animal after it is picked
            if (isGameStarted && activeAnimals.Count > 0)
            {
                var selectedAnimal = activeAnimals.Last();
                // Draw the selected animal's shelter and animal image together
                DrawSelectedAnimalAndShelter(e.Graphics, selectedAnimal);
            }
        }
        private void DrawSelectedAnimalAndShelter(Graphics g, Animal selectedAnimal)
        {
            // Draw the selected animal at its position
            g.DrawImage(selectedAnimal.AnimalImage, selectedAnimal.Position.X - 50, selectedAnimal.Position.Y - 50, 100, 100);  // Adjust size and position as needed

            // Draw the shelter near the selected animal's position
           /* if (selectedAnimal.IsInCorrectHouse)
            {
                // If the animal is placed correctly, draw its shelter near its position
                g.DrawImage(selectedAnimal.HouseImage, selectedAnimal.Position.X - 50, selectedAnimal.Position.Y - 150, 100, 100);  // Adjust position for visual balance
            }
            else
            {
                // If the animal is not placed in the correct house yet, show the shelter next to the animal
                g.DrawImage(selectedAnimal.HouseImage, selectedAnimal.Position.X + 100, selectedAnimal.Position.Y - 50, 100, 100);  // Adjust as needed
            }*/
        }


        private void DrawShelterForSelectedAnimal(Graphics g, Animal selectedAnimal)
        {
            // Assuming that the selected animal has a property for its shelter image or coordinates
            // Draw the corresponding shelter (you could use an image or a background change as per your design)
            g.DrawImage(selectedAnimal.HouseImage, selectedAnimal.Position.X - 50, selectedAnimal.Position.Y - 50, 100, 100); // Adjust position and size as needed
        }



        // Method to draw the selected animal and its shelter




        private void DrawCircularMenu(Graphics g)
        {
            if (!isGenderSelected) return;  // Don't draw if gender is not selected

            // Center of the circular menu
            PointF center = new PointF(ClientSize.Width / 2, ClientSize.Height / 2);

            // Filter animals based on gender selection and also check if they are not placed correctly
            List<Animal> selectedAnimals = isBoy
                ? animals.Where(a => (a.MarkerId == 1 || a.MarkerId == 2 || a.MarkerId == 3) && !a.IsInCorrectHouse).ToList()  // Boy's animals (Elephant, Horse, Sheep) that are not in correct house
                : animals.Where(a => (a.MarkerId == 4 || a.MarkerId == 5 || a.MarkerId == 6) && !a.IsInCorrectHouse).ToList(); // Girl's animals (Cat, Dog, Giraffe) that are not in correct house

            int animalCount = selectedAnimals.Count;
            if (animalCount == 0) return; // Ensure there are animals to display

            // Calculate the angle between each animal
            float angleIncrement = 360f / animalCount;

            // Adjust for the rotation angle
            float rotatedAngle = rotationAngle; // Use the global rotation angle

            // Draw each animal in a circular pattern
            for (int i = 0; i < animalCount; i++)
            {
                Animal animal = selectedAnimals[i];

                // Apply rotation offset to the angle
                float angle = rotatedAngle + angleIncrement * i;

                // Calculate the X and Y positions based on the angle and radius
                float x = center.X + menuRadius * (float)Math.Cos(Math.PI * angle / 180f) - 40;  // Adjusted for new size
                float y = center.Y + menuRadius * (float)Math.Sin(Math.PI * angle / 180f) - 40;  // Adjusted for new size

                // Draw the animal's image at the calculated position with a larger size (80x80 pixels)
                g.DrawImage(animal.AnimalImage, x, y, 80, 80);

                // Optionally, draw the shelter near the animal (if the animal is selected)
                if (isGameStarted && activeAnimals.Contains(animal))  // If the animal has been selected
                {
                    // Draw the shelter image near the animal
                    g.DrawImage(animal.HouseImage, x - 50, y - 50, 100, 100);  // Adjust size and position for visual balance
                }
            }
        }



        private void DrawAnimals(Graphics g)
        {
            foreach (var animal in activeAnimals)
            {
                g.DrawImage(animal.AnimalImage, animal.Position.X - 50, animal.Position.Y - 50, 100, 100);
            }
        }


        // Draw the animal houses
        // Draw only shelters for the selected gender's animals
        private void DrawHouses(Graphics g)
        {
            // Check if a gender has been selected
            if (!isGenderSelected) return; // Don't draw anything if gender is not selected

            // Filter the animals based on gender selection (Boy or Girl)
            List<Animal> selectedAnimals = isBoy
                ? animals.Where(a => a.MarkerId == 1 || a.MarkerId == 2 || a.MarkerId == 3).ToList()  // Boy's animals: Elephant, Horse, Sheep
                : animals.Where(a => a.MarkerId == 4 || a.MarkerId == 5 || a.MarkerId == 6).ToList(); // Girl's animals: Cat, Dog, Giraffe

            // Debugging: Log the selected animals and their shelters
            Debug.WriteLine("Selected animals for drawing shelters:");
            foreach (var animal in selectedAnimals)
            {
                Debug.WriteLine("Drawing shelter for animal: " + animal.Name); // Debugging output
                g.DrawImage(animal.HouseImage, animal.HousePosition.X - 50, animal.HousePosition.Y - 50, 100, 100);
            }
        }
        



        // Draw feedback message on the screen
        // Feedback drawing
        private void DrawFeedback(Graphics g)
        {
            if (!string.IsNullOrEmpty(feedbackMessage))
            {
                g.DrawString(feedbackMessage, new Font("Arial", 16, FontStyle.Bold), feedbackBrush, new PointF(20, 20));
            }
        }

// In the addTuioObject method, ensure Invalidate is triggered after feedbackMessage is set


    // In the feedbackTimer_Tick method
    

    private void UpdateBackgroundImage(Animal selectedAnimal)
        {
            this.BackgroundImage = selectedAnimal.BackgroundImage;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }
    }

public class Animal
{
 public int MarkerId { get; set; }
 public string Name { get; set; }
 public Point Position { get; set; }
 public Point HousePosition { get; set; }
 public Image AnimalImage { get; set; }
 public Image HouseImage { get; set; }
 public Image BackgroundImage { get; set; }
 public bool IsInCorrectHouse { get; set; } = false;

 public bool IsBoyAnimal { get; set; } // Indicates if this animal belongs to "Boy"
 public bool IsGirlAnimal { get; set; } // Indicates if this animal belongs to "Girl"
}

}























/*selected one only
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using TUIO;

namespace ZooEncyclopedia
{
    public partial class Form1 : Form, TuioListener
    {
        private List<Animal> animals;
        private List<Animal> activeAnimals = new List<Animal>();
        private Animal draggedAnimal;
        private TuioClient tuioClient;
        private string feedbackMessage;
        private Brush feedbackBrush;
        private Timer feedbackTimer;
        private Timer dayNightTimer;
        private int messageDuration = 2000;
        private bool allAnimalsCorrect = false;
        private bool isGameStarted = false;
        private int selectedAnimalIndex = -1;
        private string finalMessage;
        private float angle = 0;
        //private float angleIncrement = 5f;
        private const int menuRadius = 200;
        private bool isBoy = false;  // Default to false (Girl)
        private bool isGenderSelected = false;  // Flag to track if gender is selected
        private float rotationAngle = 0f;  // Store the rotation angle
        private float previousRotationAngle = 0f;  // To track the previous rotation angle for smooth transitions
        private float angleIncrement = 10f; // Increment value for rotation



        public Form1()
        {
            InitializeComponent();
            DoubleBuffered = true;
            InitializeFeedback();
            InitializeDayNightCycle();
            StartTUIOClient();
            this.Text = "Zoo Encyclopedia Game";
            this.Size = new Size(800, 600);
            SetDefaultBackground(); // Initialize default background
            InitializeAnimals(); // Initialize animals
            //ShowGenderSelectionMessage(); // Show message box to prompt gender selection
        }

        // Initialize feedback settings
        private void InitializeFeedback()
        {
            feedbackMessage = "Welcome to the Zoo Encyclopedia Game! Select an animal from the menu to start.";
            feedbackBrush = Brushes.Blue;
            feedbackTimer = new Timer();
            feedbackTimer.Interval = messageDuration;
            feedbackTimer.Tick += feedbackTimer_Tick;
            feedbackTimer.Start();
        }

        // Initialize day/night cycle based on the time of day
        private void InitializeDayNightCycle()
        {
            dayNightTimer = new Timer();
            dayNightTimer.Interval = 10000; // 10 seconds for testing (adjust to real day/night duration)
            dayNightTimer.Tick += (sender, e) =>
            {
                var currentHour = DateTime.Now.Hour;
                if (currentHour >= 6 && currentHour < 18)
                {
                    this.BackgroundImage = LoadImage("zoo3.jpg"); // Daytime background
                }
                else
                {
                    this.BackgroundImage = LoadImage("night_zoo1.jpg"); // Nighttime background
                }
                this.BackgroundImageLayout = ImageLayout.Stretch;
            };
            dayNightTimer.Start();
        }

        private void InitializeAnimals()
        {
            animals = new List<Animal> {
        new Animal { MarkerId = 1, Name = "Elephant", AnimalImage = LoadImage("elephant.jpg"), HouseImage = LoadImage("elephant_shelter.jpg"), BackgroundImage = LoadImage("zoo3.jpg") },
        new Animal { MarkerId = 2, Name = "Horse", AnimalImage = LoadImage("hourse.jpg"), HouseImage = LoadImage("hourse_shel.jpg"), BackgroundImage = LoadImage("zoo3.jpg") },
        new Animal { MarkerId = 3, Name = "Sheep", AnimalImage = LoadImage("sheep.jpg"), HouseImage = LoadImage("sheep shelter.jpg"), BackgroundImage = LoadImage("zoo3.jpg") },
        new Animal { MarkerId = 4, Name = "Cat", AnimalImage = LoadImage("cat.jpg"), HouseImage = LoadImage("cat shelter.jpg"), BackgroundImage = LoadImage("night_zoo1.jpg") },
        new Animal { MarkerId = 5, Name = "Dog", AnimalImage = LoadImage("dog.jpg"), HouseImage = LoadImage("dog_house.jpg"), BackgroundImage = LoadImage("night_zoo1.jpg") },
        new Animal { MarkerId = 6, Name = "Giraffe", AnimalImage = LoadImage("giraffe.jpg"), HouseImage = LoadImage("giraffe_safari.jpg"), BackgroundImage = LoadImage("night_zoo1.jpg") },
    };
        }


        // Load image from file
        private Image LoadImage(string path)
        {
            try
            {
                return Image.FromFile(path);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading image '{path}': {ex.Message}");
                return null;
            }
        }

        // Start TUIO client to listen for TUIO objects
        private void StartTUIOClient()
        {
            tuioClient = new TuioClient(3333);
            tuioClient.addTuioListener(this);
            tuioClient.connect();
        }


        // Show a message box prompting the user to choose TUIO 8 for Boy and TUIO 9 for Girl
        // Show a more friendly message box prompting the user to choose TUIO 8 for Boy and TUIO 9 for Girl
        /*private void ShowGenderSelectionMessage()
        {
            string message = "Please choose an option:\n" +
                             " - Boy -> 8\n" +
                             " - Girl -> 9";

            DialogResult result = MessageBox.Show(message,
                                                  "Select Gender",
                                                  MessageBoxButtons.OKCancel);

            if (result == DialogResult.Cancel)
            {
                Application.Exit(); // Exit the application if user cancels
            }
        }*/


/* public void addTuioObject(TuioObject to)
 {
     // Handle gender selection
     if (to.SymbolID == 8) // ID 8 for "Boy"
     {
         isBoy = true; // Set gender to Boy
         feedbackMessage = "You selected: Boy!";
         feedbackBrush = Brushes.Blue;
         isGenderSelected = true; // Set the gender selected flag to true
         feedbackTimer.Start();
         Invalidate();
         return; // Exit early to avoid overlapping logic
     }
     else if (to.SymbolID == 9) // ID 9 for "Girl"
     {
         isBoy = false; // Set gender to Girl
         feedbackMessage = "You selected: Girl!";
         feedbackBrush = Brushes.Pink;
         isGenderSelected = true; // Set the gender selected flag to true
         feedbackTimer.Start();
         Invalidate();
         return; // Exit early to avoid overlapping logic
     }

     // Prevent further actions until gender is selected
     if (!isGenderSelected)
     {
         feedbackMessage = "Please select a gender first!";
         feedbackBrush = Brushes.Red;
         feedbackTimer.Start();
         Invalidate();
         return;
     }

     // Handle animal selection when ID 12 is used (select animal from menu)
     if (!isGameStarted && to.SymbolID == 12)
     {
         var unplacedAnimals = animals.FindAll(a => !a.IsInCorrectHouse); // Filter out animals that are already placed

         if (unplacedAnimals.Count > 0)
         {
             // Find the animal that is selected based on the angle
             selectedAnimalIndex = (int)((angle / 360) * unplacedAnimals.Count) % unplacedAnimals.Count;
             var selectedAnimal = unplacedAnimals[selectedAnimalIndex];

             // Update background to match the selected animal's shelter
             UpdateBackgroundImage(selectedAnimal);

             if (!activeAnimals.Contains(selectedAnimal))
             {
                 activeAnimals.Clear();  // Clear previously active animals
                 activeAnimals.Add(selectedAnimal); // Add only the selected animal
             }

             feedbackMessage = $"{selectedAnimal.Name} selected!";
             feedbackBrush = Brushes.Green;
             feedbackTimer.Start();
             isGameStarted = true; // Start the game

             Invalidate(); // Redraw the screen
         }
         return; // Exit after selection
     }

     // Handle dragging an animal once it has been selected
     if (isGameStarted && selectedAnimalIndex != -1)
     {
         var selectedAnimal = activeAnimals.Last(); // Get the last active animal (the one that was just selected)

         if (selectedAnimal.MarkerId == to.SymbolID) // Check if the TUIO object matches the selected animal
         {
             int scaledX = (int)(to.X * this.ClientSize.Width); // Convert the TUIO X to screen coordinates
             int scaledY = (int)(to.Y * this.ClientSize.Height); // Convert the TUIO Y to screen coordinates

             selectedAnimal.Position = new Point(scaledX, scaledY); // Update animal position
             draggedAnimal = selectedAnimal; // Set the dragged animal to the selected one

             Invalidate(); // Redraw the screen
         }
     }
 }












 // Handle animal selection when a TUIO object is detected
 private void HandleAnimalSelection(List<Animal> selectedAnimals, TuioObject to)
{
if (!isGameStarted)
{
 var unplacedAnimals = selectedAnimals.Where(a => !a.IsInCorrectHouse).ToList();
 if (unplacedAnimals.Count > 0)
 {
     selectedAnimalIndex = (int)((angle / 360) * unplacedAnimals.Count) % unplacedAnimals.Count;
     var selectedAnimal = unplacedAnimals[selectedAnimalIndex];
     this.BackgroundImage = selectedAnimal.BackgroundImage;
     this.BackgroundImageLayout = ImageLayout.Stretch;

     if (!activeAnimals.Contains(selectedAnimal))
     {
         activeAnimals.Add(selectedAnimal);
     }
     feedbackMessage = $"{selectedAnimal.Name} selected!";
     feedbackBrush = Brushes.Green;
     feedbackTimer.Start();
     isGameStarted = true;
     Invalidate();
 }
}
}

// Update TUIO object (not used in this example, but required for TuioListener implementation)
public void updateTuioObject(TuioObject to)
{
if (to.SymbolID == 11) // ID 11 used for rotation tracking
{
 // Calculate the delta in rotation (i.e., the difference from the previous angle)
 float deltaAngle = to.Angle - previousRotationAngle;

 // Increment the rotation angle with a fixed amount each time
 rotationAngle += deltaAngle * angleIncrement; // Multiply by a factor to control speed

 // Normalize the angle to keep it within 0 - 360 degrees
 if (rotationAngle >= 360f) rotationAngle -= 360f;
 if (rotationAngle < 0f) rotationAngle += 360f;

 // Update the previous rotation angle to the current one for the next update
 previousRotationAngle = to.Angle;

 // Call Invalidate() to trigger the OnPaint method and redraw the screen
 Invalidate();
}
}




 // Remove TUIO object (not used in this example, but required for TuioListener implementation)
 public void removeTuioObject(TuioObject to)
 {
     if (isGameStarted && draggedAnimal != null && draggedAnimal.MarkerId == to.SymbolID)
     {
         CheckAnimalPlacement(draggedAnimal);
         draggedAnimal = null;
     }
 }
 private void CheckAnimalPlacement(Animal animal)
 {
     if (IsAnimalInHouse(animal))
     {
         animal.Position = animal.HousePosition;
         animal.IsInCorrectHouse = true;
         SetFeedback($"{animal.Name} placed correctly!", Brushes.Green);

         selectedAnimalIndex = -1;
         isGameStarted = false;

         CheckCompletion();
         Invalidate(); // Redraw the screen
     }
     else
     {
         animal.IsInCorrectHouse = false;
         SetFeedback("Wrong placement, try again!", Brushes.Red);
     }
 }

 private bool IsAnimalInHouse(Animal animal)
 {
     return (Math.Abs(animal.Position.X - animal.HousePosition.X) < 50 && Math.Abs(animal.Position.Y - animal.HousePosition.Y) < 50);
 }

 private void CheckCompletion()
 {
     if (animals.TrueForAll(a => a.IsInCorrectHouse) && !allAnimalsCorrect)
     {
         allAnimalsCorrect = true;
         finalMessage = "Great job, all is correct!";
         Invalidate();
     }
 }

 // Other required TUIO listener methods
 public void addTuioBlob(TuioBlob tb) { }
public void updateTuioBlob(TuioBlob tb) { }
public void removeTuioBlob(TuioBlob tb) { }
public void addTuioCursor(TuioCursor tc) { }
public void updateTuioCursor(TuioCursor tc) { }
public void removeTuioCursor(TuioCursor tc) { }
public void refresh(TuioTime time) { }

// Feedback methods
private void SetFeedback(string message, Brush color)
{
feedbackMessage = message;
feedbackBrush = color;
feedbackTimer.Start();
}

private void feedbackTimer_Tick(object sender, EventArgs e)
{
feedbackMessage = "";
Invalidate();
}

// Set the default background image
private void SetDefaultBackground()
{
this.BackgroundImage = LoadImage("zoo3.jpg"); // Set default background image
this.BackgroundImageLayout = ImageLayout.Stretch;
}

 // Override the Paint method to draw the game screen
 protected override void OnPaint(PaintEventArgs e)
 {
     base.OnPaint(e);

     if (isGenderSelected) // Only draw if gender is selected
     {
         if (!isGameStarted) // If the game is not started, show the circular menu
         {
             DrawCircularMenu(e.Graphics);
         }
         else // Once the game starts, draw only the selected animal and its shelter
         {
             // Draw the selected animal and its shelter
             DrawSelectedAnimalAndShelter(e.Graphics);
         }

         DrawFeedback(e.Graphics);
     }
     else
     {
         // Optionally, display a message before animals are shown
         e.Graphics.DrawString("Please select Boy or Girl to start.", new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new PointF(250, 250));
     }

     if (allAnimalsCorrect)
     {
         e.Graphics.DrawString(finalMessage, new Font("Arial", 20, FontStyle.Bold), Brushes.Green, new PointF(300, 300));
     }
 }

 // Method to draw the selected animal and its shelter
 private void DrawSelectedAnimalAndShelter(Graphics g)
 {
     if (activeAnimals.Count > 0)
     {
         var selectedAnimal = activeAnimals.Last(); // Get the last active animal

         // Draw the selected animal
         g.DrawImage(selectedAnimal.AnimalImage, new PointF(300, 200));

         // Draw the shelter if animal is correctly placed
         if (selectedAnimal.IsInCorrectHouse)
         {
             g.DrawImage(selectedAnimal.HouseImage, new PointF(600, 400));
         }
     }
 }


 private void DrawCircularMenu(Graphics g)
{
if (!isGenderSelected) return;  // Don't draw if gender is not selected

// Center of the circular menu
PointF center = new PointF(ClientSize.Width / 2, ClientSize.Height / 2);

// Filter animals based on gender selection
List<Animal> selectedAnimals = isBoy
 ? animals.Where(a => a.MarkerId == 1 || a.MarkerId == 2 || a.MarkerId == 3).ToList()  // Boy's animals (Elephant, Horse, Sheep)
 : animals.Where(a => a.MarkerId == 4 || a.MarkerId == 5 || a.MarkerId == 6).ToList(); // Girl's animals (Cat, Dog, Giraffe)

int animalCount = selectedAnimals.Count;
if (animalCount == 0) return; // Ensure there are animals to display

// Calculate the angle between each animal
float angleIncrement = 360f / animalCount;

// Adjust for the rotation angle
float rotatedAngle = rotationAngle; // Use the global rotation angle

// Draw each animal in a circular pattern
for (int i = 0; i < animalCount; i++)
{
 Animal animal = selectedAnimals[i];

 // Apply rotation offset to the angle
 float angle = rotatedAngle + angleIncrement * i;

 // Calculate the X and Y positions based on the angle and radius
 float x = center.X + menuRadius * (float)Math.Cos(Math.PI * angle / 180f) - 40;  // Adjusted for new size
 float y = center.Y + menuRadius * (float)Math.Sin(Math.PI * angle / 180f) - 40;  // Adjusted for new size

 // Draw the animal's image at the calculated position with a larger size (80x80 pixels)
 g.DrawImage(animal.AnimalImage, x, y, 80, 80);
}
}









 // Draw selected animals
 // Draw selected animals
 // Draw selected animals
 private void DrawAnimals(Graphics g)
 {
     foreach (var animal in activeAnimals)
     {
         // Set x to a fixed value to position the animal on the left side (you can adjust it)
         float x = 50;  // Fixed value for left position

         // Set y to be vertically centered (the middle of the screen, adjusted for animal height)
         float y = (this.ClientSize.Height - 80) / 2;  // (Height of the screen - Height of the animal) / 2

         // Draw the animal's image at the calculated position
         g.DrawImage(animal.AnimalImage, x, y, 80, 80);  // Adjust size if necessary
     }
 }


 // Draw the animal houses
 private void DrawHouses(Graphics g)
{
foreach (var animal in activeAnimals)
{
 if (animal.IsInCorrectHouse)
 {
     g.DrawImage(animal.HouseImage, new PointF(600, 400));
 }
}
}

// Draw feedback message on the screen
private void DrawFeedback(Graphics g)
{
g.DrawString(feedbackMessage, new Font("Arial", 16, FontStyle.Bold), feedbackBrush, new PointF(20, 20));
}
 private void UpdateBackgroundImage(Animal animal)
 {
     this.BackgroundImage = animal.BackgroundImage;
     this.BackgroundImageLayout = ImageLayout.Stretch;
 }
}

public class Animal
{
 public int MarkerId { get; set; }
 public string Name { get; set; }
 public Point Position { get; set; }
 public Point HousePosition { get; set; }
 public Image AnimalImage { get; set; }
 public Image HouseImage { get; set; }
 public Image BackgroundImage { get; set; }
 public bool IsInCorrectHouse { get; set; } = false;

 public bool IsBoyAnimal { get; set; } // Indicates if this animal belongs to "Boy"
 public bool IsGirlAnimal { get; set; } // Indicates if this animal belongs to "Girl"
}

}*/

































/*until rotation
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using TUIO;

namespace ZooEncyclopedia
{
    public partial class Form1 : Form, TuioListener
    {
        private List<Animal> animals;
        private List<Animal> activeAnimals = new List<Animal>();
        private Animal draggedAnimal;
        private TuioClient tuioClient;
        private string feedbackMessage;
        private Brush feedbackBrush;
        private Timer feedbackTimer;
        private Timer dayNightTimer;
        private int messageDuration = 2000;
        private bool allAnimalsCorrect = false;
        private bool isGameStarted = false;
        private int selectedAnimalIndex = -1;
        private string finalMessage;
        private float angle = 0;
        //private float angleIncrement = 5f;
        private const int menuRadius = 200;
        private bool isBoy = false;  // Default to false (Girl)
        private bool isGenderSelected = false;  // Flag to track if gender is selected
        private float rotationAngle = 0f;  // Store the rotation angle
        private float previousRotationAngle = 0f;  // To track the previous rotation angle for smooth transitions
        private float angleIncrement = 10f; // Increment value for rotation



        public Form1()
        {
            InitializeComponent();
            DoubleBuffered = true;
            InitializeFeedback();
            InitializeDayNightCycle();
            StartTUIOClient();
            this.Text = "Zoo Encyclopedia Game";
            this.Size = new Size(800, 600);
            SetDefaultBackground(); // Initialize default background
            InitializeAnimals(); // Initialize animals
            //ShowGenderSelectionMessage(); // Show message box to prompt gender selection
        }

        // Initialize feedback settings
        private void InitializeFeedback()
        {
            feedbackMessage = "Welcome to the Zoo Encyclopedia Game! Select an animal from the menu to start.";
            feedbackBrush = Brushes.Blue;
            feedbackTimer = new Timer();
            feedbackTimer.Interval = messageDuration;
            feedbackTimer.Tick += feedbackTimer_Tick;
            feedbackTimer.Start();
        }

        // Initialize day/night cycle based on the time of day
        private void InitializeDayNightCycle()
        {
            dayNightTimer = new Timer();
            dayNightTimer.Interval = 10000; // 10 seconds for testing (adjust to real day/night duration)
            dayNightTimer.Tick += (sender, e) =>
            {
                var currentHour = DateTime.Now.Hour;
                if (currentHour >= 6 && currentHour < 18)
                {
                    this.BackgroundImage = LoadImage("zoo3.jpg"); // Daytime background
                }
                else
                {
                    this.BackgroundImage = LoadImage("night_zoo1.jpg"); // Nighttime background
                }
                this.BackgroundImageLayout = ImageLayout.Stretch;
            };
            dayNightTimer.Start();
        }

        private void InitializeAnimals()
        {
            animals = new List<Animal> {
        new Animal { MarkerId = 1, Name = "Elephant", AnimalImage = LoadImage("elephant.jpg"), HouseImage = LoadImage("elephant_shelter.jpg"), BackgroundImage = LoadImage("zoo3.jpg") },
        new Animal { MarkerId = 2, Name = "Horse", AnimalImage = LoadImage("hourse.jpg"), HouseImage = LoadImage("hourse_shel.jpg"), BackgroundImage = LoadImage("zoo3.jpg") },
        new Animal { MarkerId = 3, Name = "Sheep", AnimalImage = LoadImage("sheep.jpg"), HouseImage = LoadImage("sheep shelter.jpg"), BackgroundImage = LoadImage("zoo3.jpg") },
        new Animal { MarkerId = 4, Name = "Cat", AnimalImage = LoadImage("cat.jpg"), HouseImage = LoadImage("cat shelter.jpg"), BackgroundImage = LoadImage("night_zoo1.jpg") },
        new Animal { MarkerId = 5, Name = "Dog", AnimalImage = LoadImage("dog.jpg"), HouseImage = LoadImage("dog_house.jpg"), BackgroundImage = LoadImage("night_zoo1.jpg") },
        new Animal { MarkerId = 6, Name = "Giraffe", AnimalImage = LoadImage("giraffe.jpg"), HouseImage = LoadImage("giraffe_safari.jpg"), BackgroundImage = LoadImage("night_zoo1.jpg") },
    };
        }


        // Load image from file
        private Image LoadImage(string path)
        {
            try
            {
                return Image.FromFile(path);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading image '{path}': {ex.Message}");
                return null;
            }
        }

        // Start TUIO client to listen for TUIO objects
        private void StartTUIOClient()
        {
            tuioClient = new TuioClient(3333);
            tuioClient.addTuioListener(this);
            tuioClient.connect();
        }


        // Show a message box prompting the user to choose TUIO 8 for Boy and TUIO 9 for Girl
        // Show a more friendly message box prompting the user to choose TUIO 8 for Boy and TUIO 9 for Girl
        /*private void ShowGenderSelectionMessage()
        {
            string message = "Please choose an option:\n" +
                             " - Boy -> 8\n" +
                             " - Girl -> 9";

            DialogResult result = MessageBox.Show(message,
                                                  "Select Gender",
                                                  MessageBoxButtons.OKCancel);

            if (result == DialogResult.Cancel)
            {
                Application.Exit(); // Exit the application if user cancels
            }
        }*/


/*public void addTuioObject(TuioObject to)
{
    if (to.SymbolID == 8) // ID 8 for "Boy"
    {
        isBoy = true; // Set gender to Boy
        feedbackMessage = "You selected: Boy!";
        feedbackBrush = Brushes.Blue;
        isGenderSelected = true;  // Set the gender selected flag to true
        feedbackTimer.Start();
        Invalidate();
    }
    else if (to.SymbolID == 9) // ID 9 for "Girl"
    {
        isBoy = false; // Set gender to Girl
        feedbackMessage = "You selected: Girl!";
        feedbackBrush = Brushes.Pink;
        isGenderSelected = true;  // Set the gender selected flag to true
        feedbackTimer.Start();
        Invalidate();
    }
}




// Handle animal selection when a TUIO object is detected
private void HandleAnimalSelection(List<Animal> selectedAnimals, TuioObject to)
{
    if (!isGameStarted)
    {
        var unplacedAnimals = selectedAnimals.Where(a => !a.IsInCorrectHouse).ToList();
        if (unplacedAnimals.Count > 0)
        {
            selectedAnimalIndex = (int)((angle / 360) * unplacedAnimals.Count) % unplacedAnimals.Count;
            var selectedAnimal = unplacedAnimals[selectedAnimalIndex];
            this.BackgroundImage = selectedAnimal.BackgroundImage;
            this.BackgroundImageLayout = ImageLayout.Stretch;

            if (!activeAnimals.Contains(selectedAnimal))
            {
                activeAnimals.Add(selectedAnimal);
            }
            feedbackMessage = $"{selectedAnimal.Name} selected!";
            feedbackBrush = Brushes.Green;
            feedbackTimer.Start();
            isGameStarted = true;
            Invalidate();
        }
    }
}

// Update TUIO object (not used in this example, but required for TuioListener implementation)
public void updateTuioObject(TuioObject to)
{
    if (to.SymbolID == 11) // ID 11 used for rotation tracking
    {
        // Calculate the delta in rotation (i.e., the difference from the previous angle)
        float deltaAngle = to.Angle - previousRotationAngle;

        // Increment the rotation angle with a fixed amount each time
        rotationAngle += deltaAngle * angleIncrement; // Multiply by a factor to control speed

        // Normalize the angle to keep it within 0 - 360 degrees
        if (rotationAngle >= 360f) rotationAngle -= 360f;
        if (rotationAngle < 0f) rotationAngle += 360f;

        // Update the previous rotation angle to the current one for the next update
        previousRotationAngle = to.Angle;

        // Call Invalidate() to trigger the OnPaint method and redraw the screen
        Invalidate();
    }
}




// Remove TUIO object (not used in this example, but required for TuioListener implementation)
public void removeTuioObject(TuioObject to) { }

// Other required TUIO listener methods
public void addTuioBlob(TuioBlob tb) { }
public void updateTuioBlob(TuioBlob tb) { }
public void removeTuioBlob(TuioBlob tb) { }
public void addTuioCursor(TuioCursor tc) { }
public void updateTuioCursor(TuioCursor tc) { }
public void removeTuioCursor(TuioCursor tc) { }
public void refresh(TuioTime time) { }

// Feedback methods
private void SetFeedback(string message, Brush color)
{
    feedbackMessage = message;
    feedbackBrush = color;
    feedbackTimer.Start();
}

private void feedbackTimer_Tick(object sender, EventArgs e)
{
    feedbackMessage = "";
    Invalidate();
}

// Set the default background image
private void SetDefaultBackground()
{
    this.BackgroundImage = LoadImage("zoo3.jpg"); // Set default background image
    this.BackgroundImageLayout = ImageLayout.Stretch;
}

// Override the Paint method to draw the game screen
protected override void OnPaint(PaintEventArgs e)
{
    base.OnPaint(e);

    if (isGenderSelected) // Only draw if gender is selected
    {
        DrawCircularMenu(e.Graphics);
        DrawAnimals(e.Graphics);
        DrawHouses(e.Graphics);
        DrawFeedback(e.Graphics);
    }
    else
    {
        // Optionally, display a message before animals are shown
        e.Graphics.DrawString("Please select Boy or Girl to start.", new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new PointF(250, 250));
    }

    if (allAnimalsCorrect)
    {
        e.Graphics.DrawString(finalMessage, new Font("Arial", 20, FontStyle.Bold), Brushes.Green, new PointF(300, 300));
    }

    // Apply rotation to the object (for example, drawing the circular menu)
    e.Graphics.ResetTransform();  // Reset any previous transformations
    e.Graphics.RotateTransform(rotationAngle); // Rotate by the updated angle
}
private void DrawCircularMenu(Graphics g)
{
    if (!isGenderSelected) return;  // Don't draw if gender is not selected

    // Center of the circular menu
    PointF center = new PointF(ClientSize.Width / 2, ClientSize.Height / 2);

    // Filter animals based on gender selection
    List<Animal> selectedAnimals = isBoy
        ? animals.Where(a => a.MarkerId == 1 || a.MarkerId == 2 || a.MarkerId == 3).ToList()  // Boy's animals (Elephant, Horse, Sheep)
        : animals.Where(a => a.MarkerId == 4 || a.MarkerId == 5 || a.MarkerId == 6).ToList(); // Girl's animals (Cat, Dog, Giraffe)

    int animalCount = selectedAnimals.Count;
    if (animalCount == 0) return; // Ensure there are animals to display

    // Calculate the angle between each animal
    float angleIncrement = 360f / animalCount;

    // Adjust for the rotation angle
    float rotatedAngle = rotationAngle; // Use the global rotation angle

    // Draw each animal in a circular pattern
    for (int i = 0; i < animalCount; i++)
    {
        Animal animal = selectedAnimals[i];

        // Apply rotation offset to the angle
        float angle = rotatedAngle + angleIncrement * i;

        // Calculate the X and Y positions based on the angle and radius
        float x = center.X + menuRadius * (float)Math.Cos(Math.PI * angle / 180f) - 40;  // Adjusted for new size
        float y = center.Y + menuRadius * (float)Math.Sin(Math.PI * angle / 180f) - 40;  // Adjusted for new size

        // Draw the animal's image at the calculated position with a larger size (80x80 pixels)
        g.DrawImage(animal.AnimalImage, x, y, 80, 80);
    }
}









// Draw selected animals
private void DrawAnimals(Graphics g)
{
    foreach (var animal in activeAnimals)
    {
        g.DrawImage(animal.AnimalImage, new PointF(300, 200));
    }
}

// Draw the animal houses
private void DrawHouses(Graphics g)
{
    foreach (var animal in activeAnimals)
    {
        if (animal.IsInCorrectHouse)
        {
            g.DrawImage(animal.HouseImage, new PointF(600, 400));
        }
    }
}

// Draw feedback message on the screen
private void DrawFeedback(Graphics g)
{
    g.DrawString(feedbackMessage, new Font("Arial", 16, FontStyle.Bold), feedbackBrush, new PointF(20, 20));
}
}

public class Animal
{
public int MarkerId { get; set; }
public string Name { get; set; }
public Image AnimalImage { get; set; }
public Image HouseImage { get; set; }
public Image BackgroundImage { get; set; }
public bool IsInCorrectHouse { get; set; } = false;
}
}*/





/*boy and girl with tick box
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using TUIO;

namespace ZooEncyclopedia
{
    public partial class Form1 : Form, TuioListener
    {
        private List<Animal> animals;
        private List<Animal> activeAnimals = new List<Animal>();
        private Animal draggedAnimal;
        private TuioClient tuioClient;
        private string feedbackMessage;
        private Brush feedbackBrush;
        private Timer feedbackTimer;
        private Timer dayNightTimer;
        private int messageDuration = 2000;
        private bool allAnimalsCorrect = false;
        private bool isGameStarted = false;
        private int selectedAnimalIndex = -1;
        private string finalMessage;
        private float angle = 0;
        private float angleIncrement = 5f;
        private const int menuRadius = 200;
        private bool isBoy = false;  // Default to false (Girl)

        public Form1()
        {
            InitializeComponent();
            DoubleBuffered = true;
            InitializeFeedback();
            InitializeDayNightCycle();
            StartTUIOClient();
            this.Text = "Zoo Encyclopedia Game";
            this.Size = new Size(800, 600);
            SetDefaultBackground(); // Initialize default background
            InitializeAnimals(); // Initialize animals

            ShowGenderSelection(); // Show the gender selection message box on startup
        }

        // Method to show a message box asking the user to select their gender
        private void ShowGenderSelection()
        {
            // Create a new form for gender selection
            Form genderForm = new Form
            {
                Text = "Select Your Gender",
                Size = new Size(300, 300),
                StartPosition = FormStartPosition.CenterScreen
            };

            Label label = new Label
            {
                Text = "Please select your gender:",
                Location = new Point(50, 30),
                Size = new Size(200, 30),
                Font = new Font("Arial", 12, FontStyle.Regular)
            };

            CheckBox boyCheckBox = new CheckBox
            {
                Text = "Boy",
                Location = new Point(50, 70),
                Size = new Size(100, 30),
                Font = new Font("Arial", 12, FontStyle.Regular),
                ForeColor = Color.Blue
            };

            CheckBox girlCheckBox = new CheckBox
            {
                Text = "Girl",
                Location = new Point(50, 110),
                Size = new Size(100, 30),
                Font = new Font("Arial", 12, FontStyle.Regular),
                ForeColor = Color.Pink
            };

            Button submitButton = new Button
            {
                Text = "Submit",
                Location = new Point(50, 150),
                Size = new Size(200, 30),
                Font = new Font("Arial", 12, FontStyle.Regular)
            };

            submitButton.Click += (sender, e) =>
            {
                if (boyCheckBox.Checked)
                {
                    feedbackMessage = "You selected: Boy!";
                    feedbackBrush = Brushes.Blue;
                    isBoy = true; // Set isBoy to true for boys
                }
                else if (girlCheckBox.Checked)
                {
                    feedbackMessage = "You selected: Girl!";
                    feedbackBrush = Brushes.Pink;
                    isBoy = false; // Set isBoy to false for girls
                }

                genderForm.Close();
                feedbackTimer.Start();
                Invalidate();
            };

            genderForm.Controls.Add(label);
            genderForm.Controls.Add(boyCheckBox);
            genderForm.Controls.Add(girlCheckBox);
            genderForm.Controls.Add(submitButton);

            genderForm.ShowDialog();
        }



        private void InitializeFeedback()
        {
            feedbackMessage = "Welcome to the Zoo Encyclopedia Game! Select an animal from the menu to start.";
            feedbackBrush = Brushes.Blue;
            feedbackTimer = new Timer();
            feedbackTimer.Interval = messageDuration;
            feedbackTimer.Tick += feedbackTimer_Tick;
            feedbackTimer.Start();
        }

        private void InitializeDayNightCycle()
        {
            dayNightTimer = new Timer();
            dayNightTimer.Interval = 10000; // 10 seconds for testing (adjust to real day/night duration)
            dayNightTimer.Tick += (sender, e) =>
            {
                var currentHour = DateTime.Now.Hour;
                if (currentHour >= 6 && currentHour < 18)
                {
                    this.BackgroundImage = LoadImage("zoo3.jpg"); // Daytime background
                }
                else
                {
                    this.BackgroundImage = LoadImage("night_zoo1.jpg"); // Nighttime background
                }
                this.BackgroundImageLayout = ImageLayout.Stretch;
            };
            dayNightTimer.Start();
        }

        private void InitializeAnimals()
        {
            animals = new List<Animal> {
                new Animal { MarkerId = 1, Name = "Elephant", AnimalImage = LoadImage("elephant.jpg"), HouseImage = LoadImage("elephant_shelter.jpg"), BackgroundImage = LoadImage("zoo3.jpg") },
                new Animal { MarkerId = 2, Name = "Horse", AnimalImage = LoadImage("hourse.jpg"), HouseImage = LoadImage("hourse_shel.jpg"), BackgroundImage = LoadImage("zoo3.jpg") },
                new Animal { MarkerId = 3, Name = "Sheep", AnimalImage = LoadImage("sheep.jpg"), HouseImage = LoadImage("sheep shelter.jpg"), BackgroundImage = LoadImage("zoo3.jpg") },
                new Animal { MarkerId = 4, Name = "Cat", AnimalImage = LoadImage("cat.jpg"), HouseImage = LoadImage("cat shelter.jpg"), BackgroundImage = LoadImage("night_zoo1.jpg") },
                new Animal { MarkerId = 5, Name = "Dog", AnimalImage = LoadImage("dog.jpg"), HouseImage = LoadImage("dog_house.jpg"), BackgroundImage = LoadImage("night_zoo1.jpg") },
                new Animal { MarkerId = 6, Name = "Giraffe", AnimalImage = LoadImage("giraffe.jpg"), HouseImage = LoadImage("giraffe_safari.jpg"), BackgroundImage = LoadImage("night_zoo1.jpg") },
            };
        }

        private Image LoadImage(string path)
        {
            try
            {
                return Image.FromFile(path);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading image '{path}': {ex.Message}");
                return null;
            }
        }

        private void StartTUIOClient()
        {
            tuioClient = new TuioClient(3333);
            tuioClient.addTuioListener(this);
            tuioClient.connect();
        }

        public void addTuioObject(TuioObject to)
        {
            if (!isGameStarted && to.SymbolID == 11) // Rotate menu
            {
                angle += angleIncrement;
                if (angle >= 360) angle = 0;
                Invalidate();
                return;
            }

            if (!isGameStarted && to.SymbolID == 12) // Select animal from menu
            {
                var unplacedAnimals = animals.FindAll(a => !a.IsInCorrectHouse);
                if (unplacedAnimals.Count > 0)
                {
                    selectedAnimalIndex = (int)((angle / 360) * unplacedAnimals.Count) % unplacedAnimals.Count;
                    var selectedAnimal = unplacedAnimals[selectedAnimalIndex];

                    // Update background here instead of using UpdateBackground method
                    this.BackgroundImage = selectedAnimal.BackgroundImage;
                    this.BackgroundImageLayout = ImageLayout.Stretch;

                    if (!activeAnimals.Contains(selectedAnimal))
                    {
                        activeAnimals.Add(selectedAnimal);
                    }
                    feedbackMessage = $"{selectedAnimal.Name} selected!";
                    feedbackBrush = Brushes.Green;
                    feedbackTimer.Start();
                    isGameStarted = true;
                    Invalidate();
                }
                return;
            }

            if (isGameStarted && selectedAnimalIndex != -1)
            {
                var selectedAnimal = activeAnimals.Last();
                if (selectedAnimal.MarkerId == to.SymbolID)
                {
                    int scaledX = (int)(to.X * this.ClientSize.Width);
                    int scaledY = (int)(to.Y * this.ClientSize.Height);
                    selectedAnimal.Position = new Point(scaledX, scaledY);
                    draggedAnimal = selectedAnimal;
                    Invalidate();
                }
            }
        }

        public void updateTuioObject(TuioObject to)
        {
            if (isGameStarted && selectedAnimalIndex != -1)
            {
                var selectedAnimal = activeAnimals.Last();
                if (selectedAnimal.MarkerId == to.SymbolID)
                {
                    int scaledX = (int)(to.X * this.ClientSize.Width);
                    int scaledY = (int)(to.Y * this.ClientSize.Height);
                    selectedAnimal.Position = new Point(scaledX, scaledY);
                    Invalidate();
                }
            }
        }

        public void removeTuioObject(TuioObject to)
        {
            if (isGameStarted && draggedAnimal != null && draggedAnimal.MarkerId == to.SymbolID)
            {
                CheckAnimalPlacement(draggedAnimal);
                draggedAnimal = null;
            }
        }

        public void addTuioBlob(TuioBlob tb) { }

        public void updateTuioBlob(TuioBlob tb) { }

        public void removeTuioBlob(TuioBlob tb) { }

        public void addTuioCursor(TuioCursor tc) { }

        public void updateTuioCursor(TuioCursor tc) { }

        public void removeTuioCursor(TuioCursor tc) { }

        public void refresh(TuioTime time) { }

        private void CheckAnimalPlacement(Animal animal)
        {
            if (IsAnimalInHouse(animal))
            {
                animal.Position = animal.HousePosition;
                animal.IsInCorrectHouse = true;
                SetFeedback($"{animal.Name} placed correctly!", Brushes.Green);
                selectedAnimalIndex = -1;
                isGameStarted = false;
                CheckCompletion();
                Invalidate();
            }
            else
            {
                animal.IsInCorrectHouse = false;
                SetFeedback("Wrong placement, try again!", Brushes.Red);
            }
        }

        private bool IsAnimalInHouse(Animal animal)
        {
            return (Math.Abs(animal.Position.X - animal.HousePosition.X) < 50 && Math.Abs(animal.Position.Y - animal.HousePosition.Y) < 50);
        }

        private void CheckCompletion()
        {
            if (animals.TrueForAll(a => a.IsInCorrectHouse) && !allAnimalsCorrect)
            {
                allAnimalsCorrect = true;
                finalMessage = "Great job, all is correct!";
                Invalidate();
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            DrawCircularMenu(e.Graphics);
            DrawAnimals(e.Graphics);
            DrawHouses(e.Graphics);
            DrawFeedback(e.Graphics);

            if (allAnimalsCorrect)
            {
                e.Graphics.DrawString(finalMessage, new Font("Arial", 24, FontStyle.Bold), Brushes.Blue, this.ClientSize.Width / 2 - 200, this.ClientSize.Height / 2 + 150);
            }
        }

        private void DrawCircularMenu(Graphics g)
        {
            var unplacedAnimals = isBoy
                ? animals.FindAll(a => !a.IsInCorrectHouse && (a.Name == "Elephant" || a.Name == "Horse" || a.Name == "Sheep")) // Boy's animals
                : animals.FindAll(a => !a.IsInCorrectHouse && (a.Name == "Cat" || a.Name == "Dog" || a.Name == "Giraffe")); // Girl's animals

            for (int i = 0; i < unplacedAnimals.Count; i++)
            {
                var angleOffset = (360f / unplacedAnimals.Count) * i;
                var angleRad = (angleOffset + angle) * (Math.PI / 180);
                var x = this.ClientSize.Width / 2 + menuRadius * (float)Math.Cos(angleRad);
                var y = this.ClientSize.Height / 2 + menuRadius * (float)Math.Sin(angleRad);
                g.DrawImage(unplacedAnimals[i].AnimalImage, x - 50, y - 50, 100, 100);
            }
        }


        private void DrawAnimals(Graphics g)
        {
            foreach (var animal in activeAnimals)
            {
                g.DrawImage(animal.AnimalImage, animal.Position.X, animal.Position.Y, 100, 100);
            }
        }

        private void DrawHouses(Graphics g)
        {
            foreach (var animal in animals)
            {
                g.DrawImage(animal.HouseImage, animal.HousePosition.X, animal.HousePosition.Y, 100, 100);
            }
        }

        private void DrawFeedback(Graphics g)
        {
            g.DrawString(feedbackMessage, new Font("Arial", 14, FontStyle.Regular), feedbackBrush, 10, this.ClientSize.Height - 30);
        }

        private void SetFeedback(string message, Brush color)
        {
            feedbackMessage = message;
            feedbackBrush = color;
            feedbackTimer.Start();
        }

        private void feedbackTimer_Tick(object sender, EventArgs e)
        {
            feedbackMessage = "";
            Invalidate();
        }

        private void SetDefaultBackground()
        {
            this.BackgroundImage = LoadImage("zoo3.jpg"); // Set default background image
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }
    }

    public class Animal
    {
        public int MarkerId { get; set; }
        public string Name { get; set; }
        public Image AnimalImage { get; set; }
        public Image HouseImage { get; set; }
        public Image BackgroundImage { get; set; }
        public Point Position { get; set; }
        public Point HousePosition { get; set; }
        public bool IsInCorrectHouse { get; set; }
    }
}*/










/*night and day feature
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using TUIO;

namespace ZooEncyclopedia
{
    public partial class Form1 : Form, TuioListener
    {
        private List<Animal> animals;
        private List<Animal> activeAnimals = new List<Animal>();
        private Animal draggedAnimal;
        private TuioClient tuioClient;
        private string feedbackMessage;
        private Brush feedbackBrush;
        private Timer feedbackTimer;
        private Timer dayNightTimer;
        private int messageDuration = 2000;
        private bool allAnimalsCorrect = false;
        private bool isGameStarted = false;
        private int selectedAnimalIndex = -1;
        private string finalMessage;
        private float angle = 0;
        private float angleIncrement = 5f;
        private const int menuRadius = 200;

        public Form1()
        {
            InitializeComponent();
            DoubleBuffered = true;
            InitializeFeedback();
            InitializeDayNightCycle();
            StartTUIOClient();
            this.Text = "Zoo Encyclopedia Game";
            this.Size = new Size(800, 600);
            SetDefaultBackground(); // Initialize default background
            InitializeAnimals(); // Initialize animals
        }

        private void InitializeFeedback()
        {
            feedbackMessage = "Welcome to the Zoo Encyclopedia Game! Select an animal from the menu to start.";
            feedbackBrush = Brushes.Blue;
            feedbackTimer = new Timer();
            feedbackTimer.Interval = messageDuration;
            feedbackTimer.Tick += feedbackTimer_Tick;
            feedbackTimer.Start();
        }

        private void InitializeDayNightCycle()
        {
            dayNightTimer = new Timer();
            dayNightTimer.Interval = 10000; // 10 seconds for testing (adjust to real day/night duration)
            dayNightTimer.Tick += (sender, e) =>
            {
                var currentHour = DateTime.Now.Hour;
                if (currentHour >= 6 && currentHour < 18)
                {
                    this.BackgroundImage = LoadImage("zoo3.jpg"); // Daytime background
                }
                else
                {
                    this.BackgroundImage = LoadImage("night_zoo1.jpg"); // Nighttime background
                }
                this.BackgroundImageLayout = ImageLayout.Stretch;
            };
            dayNightTimer.Start();
        }

        private void InitializeAnimals()
        {
            animals = new List<Animal> {
                new Animal { MarkerId = 1, Name = "Elephant", AnimalImage = LoadImage("elephant.jpg"), HouseImage = LoadImage("elephant_shelter.jpg"), BackgroundImage = LoadImage("zoo3.jpg") },
                new Animal { MarkerId = 2, Name = "Horse", AnimalImage = LoadImage("hourse.jpg"), HouseImage = LoadImage("hourse_shel.jpg"), BackgroundImage = LoadImage("zoo3.jpg") },
                new Animal { MarkerId = 3, Name = "Sheep", AnimalImage = LoadImage("sheep.jpg"), HouseImage = LoadImage("sheep shelter.jpg"), BackgroundImage = LoadImage("zoo3.jpg") },
                new Animal { MarkerId = 4, Name = "Cat", AnimalImage = LoadImage("cat.jpg"), HouseImage = LoadImage("cat shelter.jpg"), BackgroundImage = LoadImage("night_zoo1.jpg") },
                new Animal { MarkerId = 5, Name = "Dog", AnimalImage = LoadImage("dog.jpg"), HouseImage = LoadImage("dog_house.jpg"), BackgroundImage = LoadImage("night_zoo1.jpg") },
                new Animal { MarkerId = 6, Name = "Giraffe", AnimalImage = LoadImage("giraffe.jpg"), HouseImage = LoadImage("giraffe_safari.jpg"), BackgroundImage = LoadImage("night_zoo1.jpg") },
            };
        }

        private Image LoadImage(string path)
        {
            try
            {
                return Image.FromFile(path);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading image '{path}': {ex.Message}");
                return null;
            }
        }

        private void StartTUIOClient()
        {
            tuioClient = new TuioClient(3333);
            tuioClient.addTuioListener(this);
            tuioClient.connect();
        }

        public void addTuioObject(TuioObject to)
        {
            if (!isGameStarted && to.SymbolID == 11) // Rotate menu
            {
                angle += angleIncrement;
                if (angle >= 360) angle = 0;
                Invalidate();
                return;
            }

            if (!isGameStarted && to.SymbolID == 12) // Select animal from menu
            {
                var unplacedAnimals = animals.FindAll(a => !a.IsInCorrectHouse);
                if (unplacedAnimals.Count > 0)
                {
                    selectedAnimalIndex = (int)((angle / 360) * unplacedAnimals.Count) % unplacedAnimals.Count;
                    var selectedAnimal = unplacedAnimals[selectedAnimalIndex];
                    UpdateBackground(selectedAnimal);
                    if (!activeAnimals.Contains(selectedAnimal))
                    {
                        activeAnimals.Add(selectedAnimal);
                    }
                    feedbackMessage = $"{selectedAnimal.Name} selected!";
                    feedbackBrush = Brushes.Green;
                    feedbackTimer.Start();
                    isGameStarted = true;
                    Invalidate();
                }
                return;
            }

            if (isGameStarted && selectedAnimalIndex != -1)
            {
                var selectedAnimal = activeAnimals.Last();
                if (selectedAnimal.MarkerId == to.SymbolID)
                {
                    int scaledX = (int)(to.X * this.ClientSize.Width);
                    int scaledY = (int)(to.Y * this.ClientSize.Height);
                    selectedAnimal.Position = new Point(scaledX, scaledY);
                    draggedAnimal = selectedAnimal;
                    Invalidate();
                }
            }
        }

        public void updateTuioObject(TuioObject to)
        {
            if (isGameStarted && selectedAnimalIndex != -1)
            {
                var selectedAnimal = activeAnimals.Last();
                if (selectedAnimal.MarkerId == to.SymbolID)
                {
                    int scaledX = (int)(to.X * this.ClientSize.Width);
                    int scaledY = (int)(to.Y * this.ClientSize.Height);
                    selectedAnimal.Position = new Point(scaledX, scaledY);
                    Invalidate();
                }
            }
        }

        public void removeTuioObject(TuioObject to)
        {
            if (isGameStarted && draggedAnimal != null && draggedAnimal.MarkerId == to.SymbolID)
            {
                CheckAnimalPlacement(draggedAnimal);
                draggedAnimal = null;
            }
        }

        public void addTuioBlob(TuioBlob tb) { }

        public void updateTuioBlob(TuioBlob tb) { }

        public void removeTuioBlob(TuioBlob tb) { }

        public void addTuioCursor(TuioCursor tc) { }

        public void updateTuioCursor(TuioCursor tc) { }

        public void removeTuioCursor(TuioCursor tc) { }

        public void refresh(TuioTime time) { }

        private void CheckAnimalPlacement(Animal animal)
        {
            if (IsAnimalInHouse(animal))
            {
                animal.Position = animal.HousePosition;
                animal.IsInCorrectHouse = true;
                SetFeedback($"{animal.Name} placed correctly!", Brushes.Green);
                selectedAnimalIndex = -1;
                isGameStarted = false;
                CheckCompletion();
                Invalidate();
            }
            else
            {
                animal.IsInCorrectHouse = false;
                SetFeedback("Wrong placement, try again!", Brushes.Red);
            }
        }

        private bool IsAnimalInHouse(Animal animal)
        {
            return (Math.Abs(animal.Position.X - animal.HousePosition.X) < 50 && Math.Abs(animal.Position.Y - animal.HousePosition.Y) < 50);
        }

        private void CheckCompletion()
        {
            if (animals.TrueForAll(a => a.IsInCorrectHouse) && !allAnimalsCorrect)
            {
                allAnimalsCorrect = true;
                finalMessage = "Great job, all is correct!";
                Invalidate();
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            DrawCircularMenu(e.Graphics);
            DrawAnimals(e.Graphics);
            DrawHouses(e.Graphics);
            DrawFeedback(e.Graphics);

            if (allAnimalsCorrect)
            {
                e.Graphics.DrawString(finalMessage, new Font("Arial", 24, FontStyle.Bold), Brushes.Blue, this.ClientSize.Width / 2 - 200, this.ClientSize.Height / 2 + 150);
            }
        }

        private void DrawCircularMenu(Graphics g)
        {
            int menuCenterX = this.ClientSize.Width / 2;
            int menuCenterY = this.ClientSize.Height / 2;
            var unplacedAnimals = animals.FindAll(a => !a.IsInCorrectHouse);

            for (int i = 0; i < unplacedAnimals.Count; i++)
            {
                float angleForAnimal = angle + (360f / unplacedAnimals.Count) * i;
                int x = menuCenterX + (int)(menuRadius * Math.Cos(angleForAnimal * Math.PI / 180));
                int y = menuCenterY + (int)(menuRadius * Math.Sin(angleForAnimal * Math.PI / 180));
                g.DrawImage(unplacedAnimals[i].AnimalImage, x - 50, y - 50, 100, 100);
            }
        }

        private void DrawAnimals(Graphics g)
        {
            foreach (var animal in activeAnimals)
            {
                g.DrawImage(animal.AnimalImage, animal.Position.X - 50, animal.Position.Y - 50, 100, 100);
            }
        }

        private void DrawHouses(Graphics g)
        {
            foreach (var animal in activeAnimals)
            {
                g.DrawImage(animal.HouseImage, animal.HousePosition.X - 50, animal.HousePosition.Y - 50, 100, 100);
            }
        }

        private void DrawFeedback(Graphics g)
        {
            g.DrawString(feedbackMessage, new Font("Arial", 16, FontStyle.Bold), feedbackBrush, this.ClientSize.Width / 2 - 200, 10);
        }

        private void SetFeedback(string message, Brush brush)
        {
            feedbackMessage = message;
            feedbackBrush = brush;
            feedbackTimer.Start();
            Invalidate();
        }

        private void feedbackTimer_Tick(object sender, EventArgs e)
        {
            feedbackMessage = string.Empty;
            feedbackBrush = Brushes.Blue;
            feedbackTimer.Stop();
        }

        private void UpdateBackground(Animal animal)
        {
            if (animal.BackgroundImage != null)
            {
                this.BackgroundImage = animal.BackgroundImage;
                this.BackgroundImageLayout = ImageLayout.Stretch;
            }
        }

        private void SetDefaultBackground()
        {
            this.BackgroundImage = LoadImage("zoo3.jpg");
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }
    }

    public class Animal
    {
        public int MarkerId { get; set; }
        public string Name { get; set; }
        public Image AnimalImage { get; set; }
        public Image HouseImage { get; set; }
        public Image BackgroundImage { get; set; }
        public Point Position { get; set; }
        public Point HousePosition { get; set; }
        public bool IsInCorrectHouse { get; set; }
    }
}*/




/* dah el switching to make sure eno el day is okay
          private void InitializeDayNightCycle()
        {
            dayNightTimer = new Timer();
            dayNightTimer.Interval = 10000; // 10 seconds for testing (adjust as needed)
            dayNightTimer.Tick += (sender, e) =>
            {
                var currentHour = DateTime.Now.Hour;
                // Inverted logic: Show the opposite background
                if (currentHour >= 6 && currentHour < 18) // Daytime
                {
                    this.BackgroundImage = LoadImage("night_zoo1.jpg"); // Show night image during the day
                }
                else // Nighttime
                {
                    this.BackgroundImage = LoadImage("zoo3.jpg"); // Show day image during the night
                }
                this.BackgroundImageLayout = ImageLayout.Stretch;
            };
            dayNightTimer.Start();
        }*/



/*working
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using TUIO;

namespace ZooEncyclopedia
{
    public partial class Form1 : Form, TuioListener
    {
        private List<Animal> animals;
        private List<Animal> activeAnimals = new List<Animal>();
        private Animal draggedAnimal;
        private TuioClient tuioClient;
        private string feedbackMessage;
        private Brush feedbackBrush;
        private Timer feedbackTimer;
        private int messageDuration = 2000;
        private bool allAnimalsCorrect = false;
        private bool isGameStarted = false;
        private int selectedAnimalIndex = -1;
        private string finalMessage;
        private float angle = 0;
        private float angleIncrement = 5f;
        private const int menuRadius = 200;

        public Form1()
        {
            InitializeComponent();
            DoubleBuffered = true;
            InitializeFeedback();
            StartTUIOClient();
            this.Text = "Zoo Encyclopedia Game";
            this.Size = new Size(800, 600);
            SetDefaultBackground(); // Initialize default background
            InitializeAnimals(); // Initialize animals
        }

        private void InitializeFeedback()
        {
            feedbackMessage = "Welcome to the Zoo Encyclopedia Game! Select an animal from the menu to start.";
            feedbackBrush = Brushes.Blue;
            feedbackTimer = new Timer();
            feedbackTimer.Interval = messageDuration;
            feedbackTimer.Tick += feedbackTimer_Tick;
            feedbackTimer.Start();
        }

        private void InitializeAnimals()
        {
            animals = new List<Animal> {
                new Animal { MarkerId = 1, Name = "Elephant", AnimalImage = LoadImage("elephant.jpg"), HouseImage = LoadImage("elephant_shelter.jpg"), BackgroundImage = LoadImage("zoo3.jpg") },
                new Animal { MarkerId = 2, Name = "Horse", AnimalImage = LoadImage("hourse.jpg"), HouseImage = LoadImage("hourse_shel.jpg"), BackgroundImage = LoadImage("zoo3.jpg") },
                new Animal { MarkerId = 3, Name = "Sheep", AnimalImage = LoadImage("sheep.jpg"), HouseImage = LoadImage("sheep shelter.jpg"), BackgroundImage = LoadImage("zoo3.jpg") },
                new Animal { MarkerId = 4, Name = "Cat", AnimalImage = LoadImage("cat.jpg"), HouseImage = LoadImage("cat shelter.jpg"), BackgroundImage = LoadImage("night_zoo.jpg") },
                new Animal { MarkerId = 5, Name = "Dog", AnimalImage = LoadImage("dog.jpg"), HouseImage = LoadImage("dog_house.jpg"), BackgroundImage = LoadImage("night_zoo.jpg") },
                new Animal { MarkerId = 6, Name = "Giraffe", AnimalImage = LoadImage("giraffe.jpg"), HouseImage = LoadImage("giraffe_safari.jpg"), BackgroundImage = LoadImage("night_zoo.jpg") },
            };
        }

        private Image LoadImage(string path)
        {
            try
            {
                return Image.FromFile(path);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading image '{path}': {ex.Message}");
                return null;
            }
        }

        private void StartTUIOClient()
        {
            tuioClient = new TuioClient(3333);
            tuioClient.addTuioListener(this);
            tuioClient.connect();
        }

        public void addTuioObject(TuioObject to)
        {
            if (!isGameStarted && to.SymbolID == 11) // Rotate menu
            {
                angle += angleIncrement;
                if (angle >= 360) angle = 0;
                Invalidate();
                return;
            }

            if (!isGameStarted && to.SymbolID == 12) // Select animal from menu
            {
                var unplacedAnimals = animals.FindAll(a => !a.IsInCorrectHouse);
                if (unplacedAnimals.Count > 0)
                {
                    selectedAnimalIndex = (int)((angle / 360) * unplacedAnimals.Count) % unplacedAnimals.Count;
                    var selectedAnimal = unplacedAnimals[selectedAnimalIndex];
                    UpdateBackground(selectedAnimal);
                    if (!activeAnimals.Contains(selectedAnimal))
                    {
                        activeAnimals.Add(selectedAnimal);
                    }
                    feedbackMessage = $"{selectedAnimal.Name} selected!";
                    feedbackBrush = Brushes.Green;
                    feedbackTimer.Start();
                    isGameStarted = true;
                    Invalidate();
                }
                return;
            }

            if (isGameStarted && selectedAnimalIndex != -1)
            {
                var selectedAnimal = activeAnimals.Last();
                if (selectedAnimal.MarkerId == to.SymbolID)
                {
                    int scaledX = (int)(to.X * this.ClientSize.Width);
                    int scaledY = (int)(to.Y * this.ClientSize.Height);
                    selectedAnimal.Position = new Point(scaledX, scaledY);
                    draggedAnimal = selectedAnimal;
                    Invalidate();
                }
            }
        }

        public void updateTuioObject(TuioObject to)
        {
            if (isGameStarted && selectedAnimalIndex != -1)
            {
                var selectedAnimal = activeAnimals.Last();
                if (selectedAnimal.MarkerId == to.SymbolID)
                {
                    int scaledX = (int)(to.X * this.ClientSize.Width);
                    int scaledY = (int)(to.Y * this.ClientSize.Height);
                    selectedAnimal.Position = new Point(scaledX, scaledY);
                    Invalidate();
                }
            }
        }

        public void removeTuioObject(TuioObject to)
        {
            if (isGameStarted && draggedAnimal != null && draggedAnimal.MarkerId == to.SymbolID)
            {
                CheckAnimalPlacement(draggedAnimal);
                draggedAnimal = null;
            }
        }

        public void addTuioBlob(TuioBlob tb) { }

        public void updateTuioBlob(TuioBlob tb) { }

        public void removeTuioBlob(TuioBlob tb) { }

        public void addTuioCursor(TuioCursor tc) { }

        public void updateTuioCursor(TuioCursor tc) { }

        public void removeTuioCursor(TuioCursor tc) { }

        public void refresh(TuioTime time) { }

        private void CheckAnimalPlacement(Animal animal)
        {
            if (IsAnimalInHouse(animal))
            {
                animal.Position = animal.HousePosition;
                animal.IsInCorrectHouse = true;
                SetFeedback($"{animal.Name} placed correctly!", Brushes.Green);
                selectedAnimalIndex = -1;
                isGameStarted = false;
                CheckCompletion();
                Invalidate();
            }
            else
            {
                animal.IsInCorrectHouse = false;
                SetFeedback("Wrong placement, try again!", Brushes.Red);
            }
        }

        private bool IsAnimalInHouse(Animal animal)
        {
            return (Math.Abs(animal.Position.X - animal.HousePosition.X) < 50 && Math.Abs(animal.Position.Y - animal.HousePosition.Y) < 50);
        }

        private void CheckCompletion()
        {
            if (animals.TrueForAll(a => a.IsInCorrectHouse) && !allAnimalsCorrect)
            {
                allAnimalsCorrect = true;
                finalMessage = "Great job, all is correct!";
                Invalidate();
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            DrawCircularMenu(e.Graphics);
            DrawAnimals(e.Graphics);
            DrawHouses(e.Graphics);
            DrawFeedback(e.Graphics);

            if (allAnimalsCorrect)
            {
                e.Graphics.DrawString(finalMessage, new Font("Arial", 24, FontStyle.Bold), Brushes.Blue, this.ClientSize.Width / 2 - 200, this.ClientSize.Height / 2 + 150);
            }
        }

        private void DrawCircularMenu(Graphics g)
        {
            int menuCenterX = this.ClientSize.Width / 2;
            int menuCenterY = this.ClientSize.Height / 2;
            var unplacedAnimals = animals.FindAll(a => !a.IsInCorrectHouse);

            for (int i = 0; i < unplacedAnimals.Count; i++)
            {
                float angleForAnimal = angle + (360f / unplacedAnimals.Count) * i;
                int x = menuCenterX + (int)(menuRadius * Math.Cos(angleForAnimal * Math.PI / 180));
                int y = menuCenterY + (int)(menuRadius * Math.Sin(angleForAnimal * Math.PI / 180));
                g.DrawImage(unplacedAnimals[i].AnimalImage, x - 50, y - 50, 100, 100);
            }
        }

        private void DrawAnimals(Graphics g)
        {
            foreach (var animal in activeAnimals)
            {
                g.DrawImage(animal.AnimalImage, animal.Position.X - 50, animal.Position.Y - 50, 100, 100);
            }
        }

        private void DrawHouses(Graphics g)
        {
            foreach (var animal in animals)
            {
                g.DrawImage(animal.HouseImage, animal.HousePosition.X - 50, animal.HousePosition.Y - 50, 100, 100);
            }
        }

        private void DrawFeedback(Graphics g)
        {
            g.DrawString(feedbackMessage, this.Font, feedbackBrush, 10, 10);
        }

        private void UpdateBackground(Animal animal)
        {
            this.BackgroundImage = animal.BackgroundImage;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        private void SetDefaultBackground()
        {
            this.BackgroundImage = LoadImage("zoo3.jpg");
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        private void SetFeedback(string message, Brush color)
        {
            feedbackMessage = message;
            feedbackBrush = color;
            feedbackTimer.Start();
        }

        private void feedbackTimer_Tick(object sender, EventArgs e)
        {
            feedbackTimer.Stop();
            feedbackMessage = string.Empty;
            Invalidate();
        }
    }

    public class Animal
    {
        public int MarkerId { get; set; }
        public string Name { get; set; }
        public Point Position { get; set; }
        public Point HousePosition { get; set; }
        public Image AnimalImage { get; set; }
        public Image HouseImage { get; set; }
        public Image BackgroundImage { get; set; }
        public bool IsInCorrectHouse { get; set; } = false;
    }
}*/